plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.vecto.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vecto.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2.0"
    }

    // A fixed key is bundled so every CI build has the SAME signature.
    // That lets a new APK install over the previous one without uninstalling.
    val bundledKeystore = file("vecto-debug.keystore")

    signingConfigs {
        if (bundledKeystore.exists()) {
            getByName("debug") {
                storeFile = bundledKeystore
                storePassword = "vecto-debug"
                keyAlias = "vecto"
                keyPassword = "vecto-debug"
            }
        }
        create("release") {
            // Real key from GitHub Secrets (optional). Falls back to the bundled key.
            val envPath = System.getenv("KEYSTORE_PATH")
            val envFile = if (!envPath.isNullOrBlank()) file(envPath) else null
            if (envFile != null && envFile.exists()) {
                storeFile = envFile
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            } else if (bundledKeystore.exists()) {
                storeFile = bundledKeystore
                storePassword = "vecto-debug"
                keyAlias = "vecto"
                keyPassword = "vecto-debug"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            val releaseSigning = signingConfigs.getByName("release")
            if (releaseSigning.storeFile != null) {
                signingConfig = releaseSigning
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")

    // SVG rendering (AndroidSVG under the hood)
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-svg:2.7.0")
    implementation("com.caverock:androidsvg-aar:1.4")
}
