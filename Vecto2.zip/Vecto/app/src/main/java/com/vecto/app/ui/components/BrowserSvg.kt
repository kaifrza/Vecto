package com.vecto.app.ui.components

import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.util.Base64
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.viewinterop.AndroidView
import com.vecto.app.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private sealed interface BrowserState {
    data object Loading : BrowserState
    data object Failed : BrowserState
    data class Ready(val html: String) : BrowserState
}

/**
 * Renders the SVG with the system WebView (full browser engine: CSS, filters, masks...).
 * The SVG is shown inside an <img>, so scripts inside the file never run.
 */
@Composable
fun BrowserSvg(uri: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var state by remember(uri) { mutableStateOf<BrowserState>(BrowserState.Loading) }

    LaunchedEffect(uri) {
        val html = withContext(Dispatchers.IO) { buildHtml(context, Uri.parse(uri)) }
        state = if (html == null) BrowserState.Failed else BrowserState.Ready(html)
    }

    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when (val s = state) {
            BrowserState.Loading -> CircularProgressIndicator()
            BrowserState.Failed -> Text(
                stringResource(R.string.browser_load_failed),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            is BrowserState.Ready -> AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        setBackgroundColor(AndroidColor.TRANSPARENT)
                        settings.javaScriptEnabled = false
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        settings.setSupportZoom(true)
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        webViewClient = object : WebViewClient() {
                            // never navigate away from the SVG
                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
                        }
                    }
                },
                update = { web ->
                    // Only reload when the document actually changed (update runs on every recomposition).
                    if (web.tag != s.html) {
                        web.tag = s.html
                        web.loadDataWithBaseURL("https://vecto.invalid/", s.html, "text/html", "utf-8", null)
                    }
                }
            )
        }
    }
}

private fun buildHtml(context: Context, uri: Uri): String? {
    return try {
        val raw = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        if (raw.isEmpty() || raw.size > 15_000_000) return null
        var svg = String(raw, Charsets.UTF_8).removePrefix("\uFEFF")
        // The SVG is placed straight into the page (not an <img>), so CSS, filters, masks, <use>... all work.
        // XML prolog / DOCTYPE are not valid inside HTML, so strip them. JavaScript is disabled in this WebView.
        svg = svg.replace(Regex("<\\?xml[\\s\\S]*?\\?>"), "")
            .replace(Regex("<!DOCTYPE[^>\\[]*(\\[[\\s\\S]*?\\])?\\s*>", RegexOption.IGNORE_CASE), "")
            .trim()
        val root = Regex("<svg\\b[^>]*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(svg)
            ?: return null
        // No viewBox but numeric width/height: add one so the drawing scales instead of being cropped.
        if (!root.value.contains("viewBox", ignoreCase = true)) {
            fun num(name: String): String? =
                Regex("\\s$name\\s*=\\s*[\"']([0-9]*\\.?[0-9]+)(px)?[\"']", RegexOption.IGNORE_CASE)
                    .find(root.value)?.groupValues?.get(1)
            val w = num("width")
            val h = num("height")
            if (w != null && h != null) {
                svg = svg.replaceRange(root.range.first, root.range.first + 4, "<svg viewBox=\"0 0 $w $h\"")
            }
        }
        """
        <!doctype html><html><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=10, user-scalable=yes">
        <style>
          html,body{margin:0;width:100%;height:100%;background:transparent;overflow:hidden}
          body{display:flex;align-items:center;justify-content:center}
          body>svg{width:100%;height:100%;max-width:100%;max-height:100%}
        </style></head>
        <body>$svg</body></html>
        """.trimIndent()
    } catch (e: Exception) {
        null
    }
}
