package com.vecto.app.ui

import android.app.Application
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vecto.app.R
import com.vecto.app.data.Prefs
import com.vecto.app.data.SortMode
import com.vecto.app.data.SvgItem
import com.vecto.app.data.SvgScanner
import com.vecto.app.data.ViewerState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** A file change that is waiting for the user to approve it in a system dialog. */
sealed interface FileOp {
    data class Delete(val items: List<SvgItem>) : FileOp
    data class Rename(val item: SvgItem, val newName: String) : FileOp
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val scanner = SvgScanner(app)
    val prefs = Prefs(app)

    private val _items = MutableStateFlow<List<SvgItem>>(emptyList())
    val items: StateFlow<List<SvgItem>> = _items.asStateFlow()

    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _permission = MutableStateFlow(scanner.hasMediaPermission())
    val permission: StateFlow<Boolean> = _permission.asStateFlow()

    val query = MutableStateFlow("")
    val tab = MutableStateFlow(0)
    val album = MutableStateFlow<String?>(null)
    val selection = MutableStateFlow<Set<String>>(emptySet())

    val viewer = MutableStateFlow<ViewerState?>(null)
    val viewerOpen = MutableStateFlow(false)

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private var pendingOp: FileOp? = null
    private val _consent = MutableSharedFlow<IntentSender>(extraBufferCapacity = 1)
    /** System permission dialogs the UI must launch (Android asks before changing files of other apps). */
    val consentRequests: SharedFlow<IntentSender> = _consent.asSharedFlow()

    /** Filtered + sorted list that every tab is built from. */
    val visible: StateFlow<List<SvgItem>> =
        combine(_items, query, prefs.sort) { list, q, sort ->
            val needle = q.trim()
            val filtered = if (needle.isEmpty()) {
                list
            } else {
                list.filter {
                    it.name.contains(needle, ignoreCase = true) ||
                        it.folderName.contains(needle, ignoreCase = true)
                }
            }
            when (sort) {
                SortMode.NEWEST -> filtered.sortedByDescending { it.modifiedSec }
                SortMode.OLDEST -> filtered.sortedBy { it.modifiedSec }
                SortMode.NAME -> filtered.sortedWith(Comparator<SvgItem> { a, b -> a.name.compareTo(b.name, ignoreCase = true) })
                SortMode.SIZE -> filtered.sortedByDescending { it.sizeBytes }
            }
        }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var scanJob: Job? = null

    fun refresh() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            _permission.value = scanner.hasMediaPermission()
            if (_items.value.isEmpty()) _loading.value = true
            val result = try {
                scanner.scan(prefs.trees.value, prefs.files.value)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            _items.value = result
            _loading.value = false
        }
    }

    fun postMessage(text: String) {
        _messages.tryEmit(text)
    }

    // ----- navigation / ui state -----

    fun setTab(index: Int) {
        tab.value = index
        album.value = null
        clearSelection()
    }

    fun openAlbum(key: String?) {
        album.value = key
        clearSelection()
    }

    fun setQuery(value: String) {
        query.value = value
    }

    fun toggleSelect(uri: String) {
        selection.update { if (uri in it) it - uri else it + uri }
    }

    fun clearSelection() {
        if (selection.value.isNotEmpty()) selection.value = emptySet()
    }

    fun selectedItems(): List<SvgItem> {
        val ids = selection.value
        return _items.value.filter { it.uri in ids }
    }

    fun openViewer(list: List<SvgItem>, index: Int, external: Boolean = false) {
        if (list.isEmpty()) return
        viewer.value = ViewerState(list, index.coerceIn(0, list.lastIndex), System.nanoTime(), external)
        viewerOpen.value = true
    }

    fun closeViewer() {
        viewerOpen.value = false
    }

    /** An SVG opened from another app (file manager, share sheet). */
    fun openExternal(uri: Uri) {
        viewModelScope.launch {
            val item = withContext(Dispatchers.IO) { scanner.queryDocument(uri) }
                ?: SvgItem(
                    uri = uri.toString(),
                    name = uri.lastPathSegment ?: getApplication<Application>().getString(R.string.unknown_name),
                    sizeBytes = 0L,
                    modifiedSec = System.currentTimeMillis() / 1000,
                    folderKey = "picked",
                    folderName = getApplication<Application>().getString(R.string.opened_files)
                )
            openViewer(listOf(item), 0, external = true)
        }
    }

    // ----- favorites -----

    fun toggleFavorite(item: SvgItem) = prefs.toggleFavorite(item.uri)

    fun favoriteSelection() {
        val picked = selectedItems().map { it.uri }
        if (picked.isEmpty()) return
        val allFav = picked.all { it in prefs.favorites.value }
        prefs.setFavorites(picked, !allFav)
        clearSelection()
    }

    // ----- extra sources -----

    fun addFolder(uri: Uri) {
        persistAccess(uri)
        prefs.addTree(uri.toString())
        _messages.tryEmit(getApplication<Application>().getString(R.string.msg_folder_added))
        refresh()
    }

    fun addFiles(uris: List<Uri>) {
        viewModelScope.launch {
            val accepted = withContext(Dispatchers.IO) {
                uris.filter { uri ->
                    val item = scanner.queryDocument(uri)
                    val looksSvg = item != null && item.name.endsWith(".svg", ignoreCase = true)
                    if (looksSvg) persistAccess(uri)
                    looksSvg
                }
            }
            val app = getApplication<Application>()
            if (accepted.isEmpty()) {
                _messages.tryEmit(app.getString(R.string.msg_no_svg_picked))
            } else {
                prefs.addFiles(accepted.map { it.toString() })
                _messages.tryEmit(app.getString(R.string.msg_files_added, accepted.size))
                refresh()
            }
        }
    }

    fun clearSources() {
        val resolver = getApplication<Application>().contentResolver
        (prefs.trees.value + prefs.files.value).forEach { raw ->
            runCatching {
                resolver.releasePersistableUriPermission(
                    Uri.parse(raw),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
        }
        prefs.clearSources()
        _messages.tryEmit(getApplication<Application>().getString(R.string.msg_sources_cleared))
        refresh()
    }

    // ----- delete / rename -----

    private fun persistAccess(uri: Uri) {
        val resolver = getApplication<Application>().contentResolver
        val read = Intent.FLAG_GRANT_READ_URI_PERMISSION
        val write = Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        // Ask for read+write (needed for delete / rename); fall back to read-only providers.
        runCatching { resolver.takePersistableUriPermission(uri, read or write) }
            .onFailure { runCatching { resolver.takePersistableUriPermission(uri, read) } }
    }

    private fun text(id: Int, vararg args: Any): String = getApplication<Application>().getString(id, *args)

    private fun isMedia(item: SvgItem) = item.uri.startsWith("content://media/")

    private fun recoverableSender(e: SecurityException): IntentSender? =
        if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
            e.userAction.actionIntent.intentSender
        } else {
            null
        }

    /** Removes items from every in-memory place right away, then rescans. */
    private fun onItemsRemoved(uris: Collection<String>) {
        if (uris.isEmpty()) return
        val gone = uris.toSet()
        prefs.setFavorites(gone, false)
        selection.value = emptySet()
        _items.update { list -> list.filter { it.uri !in gone } }
        val current = viewer.value
        if (current != null) {
            val left = current.items.filter { it.uri !in gone }
            if (left.isEmpty()) {
                viewerOpen.value = false
            } else if (left.size != current.items.size) {
                viewer.value = current.copy(items = left, index = current.index.coerceAtMost(left.lastIndex))
            }
        }
        refresh()
    }

    fun deleteItems(items: List<SvgItem>) {
        if (items.isEmpty()) return
        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            val removed = ArrayList<String>()
            var failed = 0
            val media = items.filter { isMedia(it) }

            withContext(Dispatchers.IO) {
                items.filterNot { isMedia(it) }.forEach { item ->
                    val ok = try {
                        DocumentsContract.deleteDocument(resolver, item.parsedUri)
                    } catch (e: Exception) {
                        false
                    }
                    if (ok) removed += item.uri else failed++
                }
            }

            if (media.isNotEmpty()) {
                if (Build.VERSION.SDK_INT >= 30) {
                    // One system dialog for all files; they are deleted by the system when approved.
                    onItemsRemoved(removed)
                    pendingOp = FileOp.Delete(media)
                    _consent.tryEmit(MediaStore.createDeleteRequest(resolver, media.map { it.parsedUri }).intentSender)
                    return@launch
                }
                for (item in media) {
                    try {
                        val rows = withContext(Dispatchers.IO) { resolver.delete(item.parsedUri, null, null) }
                        if (rows > 0) removed += item.uri else failed++
                    } catch (e: SecurityException) {
                        val sender = recoverableSender(e)
                        if (sender != null) {
                            onItemsRemoved(removed)
                            pendingOp = FileOp.Delete(listOf(item))
                            _consent.tryEmit(sender)
                            return@launch
                        }
                        failed++
                    }
                }
            }

            onItemsRemoved(removed)
            if (removed.isNotEmpty()) postMessage(text(R.string.msg_deleted, removed.size))
            if (failed > 0) postMessage(text(R.string.msg_delete_failed))
        }
    }

    private fun sanitizeName(raw: String): String? {
        val cleaned = raw.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").trim('.', ' ')
        if (cleaned.isEmpty()) return null
        return if (cleaned.endsWith(".svg", ignoreCase = true)) cleaned else "$cleaned.svg"
    }

    fun renameItem(item: SvgItem, rawName: String) {
        val name = sanitizeName(rawName)
        if (name == null) {
            postMessage(text(R.string.msg_rename_invalid))
            return
        }
        if (name == item.name) return
        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            if (isMedia(item)) {
                if (Build.VERSION.SDK_INT >= 30) {
                    pendingOp = FileOp.Rename(item, name)
                    _consent.tryEmit(MediaStore.createWriteRequest(resolver, listOf(item.parsedUri)).intentSender)
                } else {
                    performMediaRename(item, name)
                }
            } else {
                val newUri = withContext(Dispatchers.IO) {
                    try {
                        DocumentsContract.renameDocument(resolver, item.parsedUri, name)
                    } catch (e: Exception) {
                        null
                    }
                }
                if (newUri == null) postMessage(text(R.string.msg_rename_failed)) else applyRename(item, name, newUri.toString())
            }
        }
    }

    private suspend fun performMediaRename(item: SvgItem, name: String) {
        val resolver = getApplication<Application>().contentResolver
        val values = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, name) }
        try {
            val rows = withContext(Dispatchers.IO) { resolver.update(item.parsedUri, values, null, null) }
            if (rows > 0) applyRename(item, name, item.uri) else postMessage(text(R.string.msg_rename_failed))
        } catch (e: SecurityException) {
            val sender = if (Build.VERSION.SDK_INT == 29) recoverableSender(e) else null
            if (sender != null) {
                pendingOp = FileOp.Rename(item, name)
                _consent.tryEmit(sender)
            } else {
                postMessage(text(R.string.msg_rename_failed))
            }
        }
    }

    private fun applyRename(old: SvgItem, name: String, newUri: String) {
        val newPath = if (old.path.contains('/') && !old.path.startsWith("content:")) {
            old.path.substringBeforeLast('/') + "/" + name
        } else {
            old.path
        }
        val renamed = old.copy(uri = newUri, name = name, path = newPath)
        if (newUri != old.uri && old.uri in prefs.favorites.value) {
            prefs.setFavorites(listOf(old.uri), false)
            prefs.setFavorites(listOf(newUri), true)
        }
        _items.update { list -> list.map { if (it.uri == old.uri) renamed else it } }
        viewer.value = viewer.value?.let { v ->
            v.copy(items = v.items.map { if (it.uri == old.uri) renamed else it })
        }
        postMessage(text(R.string.msg_renamed))
        refresh()
    }

    /** Called by the UI after the system permission dialog closed. */
    fun onConsentResult(approved: Boolean) {
        val op = pendingOp ?: return
        pendingOp = null
        if (!approved) {
            postMessage(text(R.string.msg_cancelled))
            return
        }
        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            when (op) {
                is FileOp.Delete -> {
                    val removed = if (Build.VERSION.SDK_INT >= 30) {
                        op.items.map { it.uri } // the system already deleted them
                    } else {
                        withContext(Dispatchers.IO) {
                            op.items.filter { item ->
                                try {
                                    resolver.delete(item.parsedUri, null, null) > 0
                                } catch (e: Exception) {
                                    false
                                }
                            }.map { it.uri }
                        }
                    }
                    onItemsRemoved(removed)
                    if (removed.isNotEmpty()) postMessage(text(R.string.msg_deleted, removed.size))
                }
                is FileOp.Rename -> performMediaRename(op.item, op.newName)
            }
        }
    }
}
