package com.vecto.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.vecto.app.R
import com.vecto.app.data.SortMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptionsSheet(
    sort: SortMode,
    columns: Int,
    fit: Boolean,
    theme: Int,
    hasSources: Boolean,
    onSort: (SortMode) -> Unit,
    onColumns: (Int) -> Unit,
    onFit: (Boolean) -> Unit,
    onTheme: (Int) -> Unit,
    onAddFolder: () -> Unit,
    onOpenFiles: () -> Unit,
    onRefresh: () -> Unit,
    onClearSources: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
                .navigationBarsPadding()
        ) {
            Section(stringResource(R.string.options_sort)) {
                Chip(stringResource(R.string.sort_newest), sort == SortMode.NEWEST) { onSort(SortMode.NEWEST) }
                Chip(stringResource(R.string.sort_oldest), sort == SortMode.OLDEST) { onSort(SortMode.OLDEST) }
                Chip(stringResource(R.string.sort_name), sort == SortMode.NAME) { onSort(SortMode.NAME) }
                Chip(stringResource(R.string.sort_size), sort == SortMode.SIZE) { onSort(SortMode.SIZE) }
            }
            Section(stringResource(R.string.options_grid)) {
                (2..6).forEach { n -> Chip(n.toString(), columns == n) { onColumns(n) } }
            }
            Section(stringResource(R.string.options_thumbs)) {
                Chip(stringResource(R.string.thumbs_fit), fit) { onFit(true) }
                Chip(stringResource(R.string.thumbs_fill), !fit) { onFit(false) }
            }
            Section(stringResource(R.string.options_theme)) {
                Chip(stringResource(R.string.theme_system), theme == 0) { onTheme(0) }
                Chip(stringResource(R.string.theme_light), theme == 1) { onTheme(1) }
                Chip(stringResource(R.string.theme_dark), theme == 2) { onTheme(2) }
            }
            Spacer(Modifier.height(8.dp))
            ActionRow(Icons.Rounded.FolderOpen, stringResource(R.string.add_folder)) { onDismiss(); onAddFolder() }
            ActionRow(Icons.Rounded.Image, stringResource(R.string.open_files)) { onDismiss(); onOpenFiles() }
            ActionRow(Icons.Rounded.Refresh, stringResource(R.string.action_refresh)) { onDismiss(); onRefresh() }
            if (hasSources) {
                ActionRow(Icons.Rounded.Close, stringResource(R.string.action_clear_sources)) { onDismiss(); onClearSources() }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(Modifier.padding(bottom = 14.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) { content() }
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
private fun ActionRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
