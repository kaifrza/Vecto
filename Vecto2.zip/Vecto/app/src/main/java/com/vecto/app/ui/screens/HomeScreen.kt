package com.vecto.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vecto.app.R
import com.vecto.app.data.Album
import com.vecto.app.data.SortMode
import com.vecto.app.data.SvgItem
import com.vecto.app.data.groupAlbums
import com.vecto.app.ui.MainViewModel
import com.vecto.app.ui.components.EmptyState
import com.vecto.app.ui.components.GridEntry
import com.vecto.app.ui.components.PhotoGrid
import com.vecto.app.ui.components.SkeletonGrid
import com.vecto.app.ui.components.SvgThumb
import com.vecto.app.ui.components.TopBar
import com.vecto.app.ui.components.buildEntries
import com.vecto.app.ui.shareItems

private data class TabSpec(val label: Int, val selected: ImageVector, val unselected: ImageVector)

private val Tabs = listOf(
    TabSpec(R.string.tab_photos, Icons.Rounded.PhotoLibrary, Icons.Outlined.PhotoLibrary),
    TabSpec(R.string.tab_albums, Icons.Rounded.Folder, Icons.Outlined.Folder),
    TabSpec(R.string.tab_favorites, Icons.Rounded.Favorite, Icons.Outlined.FavoriteBorder)
)

private enum class Library { LOADING, NEEDS_PERMISSION, EMPTY, NO_RESULTS, READY }

private val GridPadding = PaddingValues(start = 2.dp, end = 2.dp, bottom = 16.dp)

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onRequestAccess: () -> Unit,
    onAddFolder: () -> Unit,
    onOpenFiles: () -> Unit
) {
    val context = LocalContext.current
    val items by vm.items.collectAsStateWithLifecycle()
    val visible by vm.visible.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val permission by vm.permission.collectAsStateWithLifecycle()
    val tab by vm.tab.collectAsStateWithLifecycle()
    val albumKey by vm.album.collectAsStateWithLifecycle()
    val selection by vm.selection.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val favorites by vm.prefs.favorites.collectAsStateWithLifecycle()
    val columns by vm.prefs.columns.collectAsStateWithLifecycle()
    val fit by vm.prefs.fit.collectAsStateWithLifecycle()
    val sort by vm.prefs.sort.collectAsStateWithLifecycle()
    val theme by vm.prefs.theme.collectAsStateWithLifecycle()
    val trees by vm.prefs.trees.collectAsStateWithLifecycle()
    val files by vm.prefs.files.collectAsStateWithLifecycle()

    val snackbar = remember { SnackbarHostState() }
    var showOptions by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<List<SvgItem>?>(null) }
    val shareFailed = stringResource(R.string.msg_share_failed)
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    val photosState = rememberLazyGridState()
    val albumsState = rememberLazyGridState()
    val albumDetailState = rememberLazyGridState()
    val favoritesState = rememberLazyGridState()

    val grouped = sort == SortMode.NEWEST || sort == SortMode.OLDEST
    val today = stringResource(R.string.today)
    val yesterday = stringResource(R.string.yesterday)

    val photoEntries = remember(visible, grouped, today, yesterday) { buildEntries(visible, grouped, today, yesterday) }
    val albums = remember(visible) { groupAlbums(visible) }
    val albumItems = remember(albums, albumKey) { albums.firstOrNull { it.key == albumKey }?.items.orEmpty() }
    val albumEntries = remember(albumItems, grouped, today, yesterday) { buildEntries(albumItems, grouped, today, yesterday) }
    val favoriteItems = remember(visible, favorites) { visible.filter { it.uri in favorites } }
    val favoriteEntries = remember(favoriteItems, grouped, today, yesterday) { buildEntries(favoriteItems, grouped, today, yesterday) }

    val library = when {
        loading && items.isEmpty() -> Library.LOADING
        items.isEmpty() && !permission -> Library.NEEDS_PERMISSION
        items.isEmpty() -> Library.EMPTY
        visible.isEmpty() -> Library.NO_RESULTS
        else -> Library.READY
    }

    val selecting = selection.isNotEmpty()
    BackHandler(enabled = selecting || query.isNotEmpty() || albumKey != null || tab != 0) {
        when {
            selecting -> vm.clearSelection()
            query.isNotEmpty() -> vm.setQuery("")
            albumKey != null -> vm.openAlbum(null)
            else -> vm.setTab(0)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Box(
                Modifier
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                TopBar(
                    query = query,
                    onQueryChange = vm::setQuery,
                    onMenu = { showOptions = true },
                    selectedCount = selection.size,
                    onClearSelection = vm::clearSelection,
                    onFavoriteSelection = vm::favoriteSelection,
                    onDeleteSelection = { confirmDelete = vm.selectedItems() },
                    onShareSelection = {
                        if (!shareItems(context, vm.selectedItems())) {
                            vm.postMessage(shareFailed)
                        }
                        vm.clearSelection()
                    }
                )
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                Tabs.forEachIndexed { index, spec ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { vm.setTab(index) },
                        icon = {
                            Icon(
                                if (tab == index) spec.selected else spec.unselected,
                                contentDescription = null
                            )
                        },
                        label = { Text(stringResource(spec.label)) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Box(
            Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            Crossfade(targetState = tab, label = "tabs") { current ->
                when (current) {
                    0 -> LibraryGate(
                        library = library,
                        columns = columns,
                        onRequestAccess = onRequestAccess,
                        onAddFolder = onAddFolder,
                        onOpenFiles = onOpenFiles
                    ) {
                        PhotoGrid(
                            entries = photoEntries,
                            columns = columns,
                            fit = fit,
                            selection = selection,
                            favorites = favorites,
                            onOpen = { vm.openViewer(visible, it) },
                            onToggleSelect = { vm.toggleSelect(it.uri) },
                            modifier = Modifier.fillMaxSize(),
                            state = photosState,
                            contentPadding = GridPadding,
                            onColumnsChange = vm.prefs::setColumns,
                            topContent = if (!permission) {
                                { PermissionBanner(onRequestAccess) }
                            } else {
                                null
                            }
                        )
                    }

                    1 -> LibraryGate(
                        library = library,
                        columns = columns,
                        onRequestAccess = onRequestAccess,
                        onAddFolder = onAddFolder,
                        onOpenFiles = onOpenFiles
                    ) {
                        if (albumKey == null) {
                            AlbumList(albums, albumsState) { vm.openAlbum(it) }
                        } else {
                            Column(Modifier.fillMaxSize()) {
                                AlbumHeader(
                                    name = albums.firstOrNull { it.key == albumKey }?.name.orEmpty(),
                                    onBack = { vm.openAlbum(null) }
                                )
                                PhotoGrid(
                                    entries = albumEntries,
                                    columns = columns,
                                    fit = fit,
                                    selection = selection,
                                    favorites = favorites,
                                    onOpen = { vm.openViewer(albumItems, it) },
                                    onToggleSelect = { vm.toggleSelect(it.uri) },
                                    modifier = Modifier.fillMaxSize(),
                                    state = albumDetailState,
                                    contentPadding = GridPadding,
                                    onColumnsChange = vm.prefs::setColumns
                                )
                            }
                        }
                    }

                    else -> if (favoriteItems.isEmpty()) {
                        EmptyState(
                            title = stringResource(R.string.fav_empty_title),
                            body = stringResource(R.string.fav_empty_body)
                        )
                    } else {
                        PhotoGrid(
                            entries = favoriteEntries,
                            columns = columns,
                            fit = fit,
                            selection = selection,
                            favorites = favorites,
                            onOpen = { vm.openViewer(favoriteItems, it) },
                            onToggleSelect = { vm.toggleSelect(it.uri) },
                            modifier = Modifier.fillMaxSize(),
                            state = favoritesState,
                            contentPadding = GridPadding,
                            onColumnsChange = vm.prefs::setColumns
                        )
                    }
                }
            }
        }
    }

    confirmDelete?.let { pending ->
        DeleteDialog(
            count = pending.size,
            onConfirm = {
                confirmDelete = null
                vm.deleteItems(pending)
            },
            onDismiss = { confirmDelete = null }
        )
    }

    if (showOptions) {
        OptionsSheet(
            sort = sort,
            columns = columns,
            fit = fit,
            theme = theme,
            hasSources = trees.isNotEmpty() || files.isNotEmpty(),
            onSort = vm.prefs::setSort,
            onColumns = vm.prefs::setColumns,
            onFit = vm.prefs::setFit,
            onTheme = vm.prefs::setTheme,
            onAddFolder = onAddFolder,
            onOpenFiles = onOpenFiles,
            onRefresh = vm::refresh,
            onClearSources = vm::clearSources,
            onDismiss = { showOptions = false }
        )
    }
}

/** Shows the right empty / loading / permission screen, or [content] when there is something to show. */
@Composable
private fun LibraryGate(
    library: Library,
    columns: Int,
    onRequestAccess: () -> Unit,
    onAddFolder: () -> Unit,
    onOpenFiles: () -> Unit,
    content: @Composable () -> Unit
) {
    when (library) {
        Library.LOADING -> SkeletonGrid(columns = columns, modifier = Modifier.fillMaxSize())
        Library.NEEDS_PERMISSION -> EmptyState(
            title = stringResource(R.string.perm_title),
            body = stringResource(R.string.perm_body)
        ) {
            Button(onClick = onRequestAccess) { Text(stringResource(R.string.perm_allow)) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onAddFolder) { Text(stringResource(R.string.add_folder)) }
                TextButton(onClick = onOpenFiles) { Text(stringResource(R.string.open_files)) }
            }
        }
        Library.EMPTY -> EmptyState(
            title = stringResource(R.string.empty_title),
            body = stringResource(R.string.empty_body)
        ) {
            FilledTonalButton(onClick = onAddFolder) { Text(stringResource(R.string.add_folder)) }
            TextButton(onClick = onOpenFiles) { Text(stringResource(R.string.open_files)) }
        }
        Library.NO_RESULTS -> EmptyState(
            title = stringResource(R.string.no_results_title),
            body = stringResource(R.string.no_results_body)
        )
        Library.READY -> content()
    }
}

@Composable
private fun PermissionBanner(onAllow: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            Modifier.padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                stringResource(R.string.perm_banner),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onAllow) { Text(stringResource(R.string.perm_banner_action)) }
        }
    }
}

@Composable
private fun AlbumHeader(name: String, onBack: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 8.dp, end = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.album_back))
        }
        Text(
            name,
            style = MaterialTheme.typography.titleLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun AlbumList(albums: List<Album>, state: LazyGridState, onOpen: (String) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        state = state,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(albums, key = { it.key }) { album ->
            AlbumCard(album) { onOpen(album.key) }
        }
    }
}

@Composable
private fun AlbumCard(album: Album, onClick: () -> Unit) {
    val context = LocalContext.current
    val count = album.items.size
    Column(
        Modifier
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(18.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            if (count >= 4) {
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        SvgThumb(album.items[0], fit = true, px = 192, modifier = Modifier.weight(1f).fillMaxHeight())
                        SvgThumb(album.items[1], fit = true, px = 192, modifier = Modifier.weight(1f).fillMaxHeight())
                    }
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        SvgThumb(album.items[2], fit = true, px = 192, modifier = Modifier.weight(1f).fillMaxHeight())
                        SvgThumb(album.items[3], fit = true, px = 192, modifier = Modifier.weight(1f).fillMaxHeight())
                    }
                }
            } else {
                SvgThumb(album.items.first(), fit = true, modifier = Modifier.fillMaxSize())
            }
        }
        Text(
            album.name,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 4.dp, top = 8.dp)
        )
        Text(
            context.resources.getQuantityString(R.plurals.items_count, count, count),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
    }
}
