package com.vecto.app.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.vecto.app.data.SvgItem
import com.vecto.app.ui.theme.HeartColor

/** A rendered thumbnail of one SVG with a graceful fallback icon. No click handling. */
@Composable
fun SvgThumb(
    item: SvgItem,
    fit: Boolean,
    modifier: Modifier = Modifier,
    px: Int = 320
) {
    val context = LocalContext.current
    var failed by remember(item.uri) { mutableStateOf(false) }
    val request = remember(item.uri, item.modifiedSec, px) {
        ImageRequest.Builder(context)
            .data(item.parsedUri)
            .size(px)
            .setParameter("m", item.modifiedSec)
            .crossfade(true)
            .build()
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        AsyncImage(
            model = request,
            contentDescription = item.title,
            contentScale = if (fit) ContentScale.Fit else ContentScale.Crop,
            onError = { failed = true },
            modifier = Modifier
                .fillMaxSize()
                .padding(if (fit) 12.dp else 0.dp)
        )
        if (failed) {
            Icon(
                Icons.Rounded.Image,
                contentDescription = null,
                modifier = Modifier.size(28.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }
    }
}

/** Grid cell: shrinks and shows a check when selected, like the system Photos app. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SvgTile(
    item: SvgItem,
    fit: Boolean,
    selected: Boolean,
    selectionMode: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 0.84f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "tileScale"
    )
    val radius by animateDpAsState(if (selected) 16.dp else 4.dp, label = "tileRadius")

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .clip(RoundedCornerShape(radius))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            SvgThumb(item = item, fit = fit, modifier = Modifier.fillMaxSize())
            if (favorite && !selectionMode) {
                Icon(
                    Icons.Rounded.Favorite,
                    contentDescription = null,
                    tint = HeartColor,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .size(16.dp)
                )
            }
        }
        if (selectionMode) {
            SelectionDot(
                selected = selected,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
            )
        }
    }
}

@Composable
private fun SelectionDot(selected: Boolean, modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    Box(
        modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(if (selected) primary else Color.Black.copy(alpha = 0.28f))
            .border(2.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(
                Icons.Rounded.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}
