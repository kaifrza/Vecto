package com.vecto.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape

/*
 * Design brief
 *  - Personality: calm + precise (a tool for people who care about shapes).
 *  - Neutrals: cool blue-grey, never pure white / black.
 *  - Accent: one indigo, used only for selection, primary actions and focus.
 *  - Type: system sans, three weights, tight headings.
 *  - Hero moment: the bezier-curve motif (icon, splash, empty states).
 */

val HeartColor = Color(0xFFE5484D)

private val LightColors = lightColorScheme(
    primary = Color(0xFF4F46E5),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE4E3FF),
    onPrimaryContainer = Color(0xFF1B1A6B),
    secondary = Color(0xFF5C5F7A),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE3E4F4),
    onSecondaryContainer = Color(0xFF191B33),
    tertiary = Color(0xFF0E8F7E),
    background = Color(0xFFF8F8FC),
    onBackground = Color(0xFF1A1B24),
    surface = Color(0xFFF8F8FC),
    onSurface = Color(0xFF1A1B24),
    surfaceVariant = Color(0xFFE5E5F0),
    onSurfaceVariant = Color(0xFF474858),
    outline = Color(0xFF777889),
    outlineVariant = Color(0xFFC8C8D8),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF2F2F8),
    surfaceContainer = Color(0xFFECECF4),
    surfaceContainerHigh = Color(0xFFE6E6EF),
    surfaceContainerHighest = Color(0xFFE0E0EA),
    error = Color(0xFFBA1A1A)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB9B8FF),
    onPrimary = Color(0xFF1E1D8F),
    primaryContainer = Color(0xFF34329E),
    onPrimaryContainer = Color(0xFFE4E3FF),
    secondary = Color(0xFFC3C5E0),
    onSecondary = Color(0xFF2C2E45),
    secondaryContainer = Color(0xFF383A52),
    onSecondaryContainer = Color(0xFFDDE0FA),
    tertiary = Color(0xFF5DD9C4),
    background = Color(0xFF0F1015),
    onBackground = Color(0xFFE6E6F0),
    surface = Color(0xFF0F1015),
    onSurface = Color(0xFFE6E6F0),
    surfaceVariant = Color(0xFF2A2B38),
    onSurfaceVariant = Color(0xFFC4C4D4),
    outline = Color(0xFF8E8FA0),
    outlineVariant = Color(0xFF3A3B4A),
    surfaceContainerLowest = Color(0xFF0A0B10),
    surfaceContainerLow = Color(0xFF161720),
    surfaceContainer = Color(0xFF1B1C26),
    surfaceContainerHigh = Color(0xFF252631),
    surfaceContainerHighest = Color(0xFF30313D),
    error = Color(0xFFFFB4AB)
)

private val VectoTypography = Typography(
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.4).sp),
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.2.sp)
)

private val VectoShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun VectoTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = VectoTypography,
        shapes = VectoShapes,
        content = content
    )
}
