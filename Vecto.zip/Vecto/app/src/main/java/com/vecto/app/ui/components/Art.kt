package com.vecto.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.ceil

/** Hero illustration: a bezier curve with its anchor squares and control handles. Follows the theme. */
@Composable
fun VectorArt(modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val container = MaterialTheme.colorScheme.primaryContainer
    val tile = MaterialTheme.colorScheme.surfaceContainerHighest
    val outline = MaterialTheme.colorScheme.outline
    val accent = Color(0xFFFFB020)

    Canvas(modifier.size(width = 240.dp, height = 170.dp)) {
        val w = size.width
        val h = size.height
        val stroke = 1.5.dp.toPx()

        drawRoundRect(
            color = container,
            topLeft = Offset(w * 0.06f, h * 0.08f),
            size = Size(w * 0.88f, h * 0.84f),
            cornerRadius = CornerRadius(28.dp.toPx())
        )
        // floating "file" tiles
        drawRoundRect(tile, Offset(w * 0.12f, h * 0.16f), Size(w * 0.2f, h * 0.22f), CornerRadius(10.dp.toPx()))
        drawRoundRect(tile, Offset(w * 0.68f, h * 0.60f), Size(w * 0.2f, h * 0.22f), CornerRadius(10.dp.toPx()))

        val start = Offset(w * 0.2f, h * 0.72f)
        val c1 = Offset(w * 0.32f, h * 0.14f)
        val c2 = Offset(w * 0.66f, h * 0.88f)
        val end = Offset(w * 0.8f, h * 0.28f)

        // handles
        drawLine(outline.copy(alpha = 0.55f), start, c1, strokeWidth = stroke)
        drawLine(outline.copy(alpha = 0.55f), end, c2, strokeWidth = stroke)

        // curve
        val path = Path().apply {
            moveTo(start.x, start.y)
            cubicTo(c1.x, c1.y, c2.x, c2.y, end.x, end.y)
        }
        drawPath(path, primary, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round))

        // anchors (squares) and control points (circles)
        val a = 6.dp.toPx()
        drawRect(primary, Offset(start.x - a, start.y - a), Size(a * 2, a * 2))
        drawRect(primary, Offset(end.x - a, end.y - a), Size(a * 2, a * 2))
        drawCircle(accent, radius = 4.5.dp.toPx(), center = c1)
        drawCircle(accent, radius = 4.5.dp.toPx(), center = c2)
    }
}

/** Neutral checkerboard so transparent areas of an SVG are visible. */
@Composable
fun CheckerBoard(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cell = 14.dp.toPx()
        drawRect(Color.White)
        val cols = ceil(size.width / cell).toInt()
        val rows = ceil(size.height / cell).toInt()
        val dark = Color(0xFFE2E3E8)
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if ((r + c) % 2 == 1) {
                    drawRect(dark, Offset(c * cell, r * cell), Size(cell, cell))
                }
            }
        }
    }
}
