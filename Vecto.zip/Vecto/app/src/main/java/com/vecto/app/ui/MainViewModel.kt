package com.vecto.app.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vecto.app.R
import com.vecto.app.data.Prefs
import com.vecto.app.data.SortMode
import com.vecto.app.data.SvgItem
import com.vecto.app.data.SvgScanner
import com.vecto.app.data.ViewerState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val scanner = SvgScanner(app)
    val prefs = Prefs(app)

    private val _items = MutableStateFlow<List<SvgItem>>(emptyList())
    val items: StateFlow<List<SvgItem>> = _items.asStateFlow()

    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _permission = MutableStateFlow(scanner.hasMediaPermission())
    val permission: StateFlow<Boolean> = _permission.asStateFlow()

    val query = MutableStateFlow("")
    val tab = MutableStateFlow(0)
    val album = MutableStateFlow<String?>(null)
    val selection = MutableStateFlow<Set<String>>(emptySet())

    val viewer = MutableStateFlow<ViewerState?>(null)
    val viewerOpen = MutableStateFlow(false)

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    /** Filtered + sorted list that every tab is built from. */
    val visible: StateFlow<List<SvgItem>> =
        combine(_items, query, prefs.sort) { list, q, sort ->
            val needle = q.trim()
            val filtered = if (needle.isEmpty()) {
                list
            } else {
                list.filter {
                    it.name.contains(needle, ignoreCase = true) ||
                        it.folderName.contains(needle, ignoreCase = true)
                }
            }
            when (sort) {
                SortMode.NEWEST -> filtered.sortedByDescending { it.modifiedSec }
                SortMode.OLDEST -> filtered.sortedBy { it.modifiedSec }
                SortMode.NAME -> filtered.sortedWith(Comparator<SvgItem> { a, b -> a.name.compareTo(b.name, ignoreCase = true) })
                SortMode.SIZE -> filtered.sortedByDescending { it.sizeBytes }
            }
        }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var scanJob: Job? = null

    fun refresh() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            _permission.value = scanner.hasMediaPermission()
            if (_items.value.isEmpty()) _loading.value = true
            val result = try {
                scanner.scan(prefs.trees.value, prefs.files.value)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            _items.value = result
            _loading.value = false
        }
    }

    fun postMessage(text: String) {
        _messages.tryEmit(text)
    }

    // ----- navigation / ui state -----

    fun setTab(index: Int) {
        tab.value = index
        album.value = null
        clearSelection()
    }

    fun openAlbum(key: String?) {
        album.value = key
        clearSelection()
    }

    fun setQuery(value: String) {
        query.value = value
    }

    fun toggleSelect(uri: String) {
        selection.update { if (uri in it) it - uri else it + uri }
    }

    fun clearSelection() {
        if (selection.value.isNotEmpty()) selection.value = emptySet()
    }

    fun selectedItems(): List<SvgItem> {
        val ids = selection.value
        return _items.value.filter { it.uri in ids }
    }

    fun openViewer(list: List<SvgItem>, index: Int, external: Boolean = false) {
        if (list.isEmpty()) return
        viewer.value = ViewerState(list, index.coerceIn(0, list.lastIndex), System.nanoTime(), external)
        viewerOpen.value = true
    }

    fun closeViewer() {
        viewerOpen.value = false
    }

    /** An SVG opened from another app (file manager, share sheet). */
    fun openExternal(uri: Uri) {
        viewModelScope.launch {
            val item = withContext(Dispatchers.IO) { scanner.queryDocument(uri) }
                ?: SvgItem(
                    uri = uri.toString(),
                    name = uri.lastPathSegment ?: getApplication<Application>().getString(R.string.unknown_name),
                    sizeBytes = 0L,
                    modifiedSec = System.currentTimeMillis() / 1000,
                    folderKey = "picked",
                    folderName = getApplication<Application>().getString(R.string.opened_files)
                )
            openViewer(listOf(item), 0, external = true)
        }
    }

    // ----- favorites -----

    fun toggleFavorite(item: SvgItem) = prefs.toggleFavorite(item.uri)

    fun favoriteSelection() {
        val picked = selectedItems().map { it.uri }
        if (picked.isEmpty()) return
        val allFav = picked.all { it in prefs.favorites.value }
        prefs.setFavorites(picked, !allFav)
        clearSelection()
    }

    // ----- extra sources -----

    fun addFolder(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        prefs.addTree(uri.toString())
        _messages.tryEmit(getApplication<Application>().getString(R.string.msg_folder_added))
        refresh()
    }

    fun addFiles(uris: List<Uri>) {
        viewModelScope.launch {
            val accepted = withContext(Dispatchers.IO) {
                uris.filter { uri ->
                    val item = scanner.queryDocument(uri)
                    val looksSvg = item != null && item.name.endsWith(".svg", ignoreCase = true)
                    if (looksSvg) {
                        runCatching {
                            getApplication<Application>().contentResolver
                                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                    }
                    looksSvg
                }
            }
            val app = getApplication<Application>()
            if (accepted.isEmpty()) {
                _messages.tryEmit(app.getString(R.string.msg_no_svg_picked))
            } else {
                prefs.addFiles(accepted.map { it.toString() })
                _messages.tryEmit(app.getString(R.string.msg_files_added, accepted.size))
                refresh()
            }
        }
    }

    fun clearSources() {
        val resolver = getApplication<Application>().contentResolver
        (prefs.trees.value + prefs.files.value).forEach { raw ->
            runCatching { resolver.releasePersistableUriPermission(Uri.parse(raw), Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
        prefs.clearSources()
        _messages.tryEmit(getApplication<Application>().getString(R.string.msg_sources_cleared))
        refresh()
    }
}
