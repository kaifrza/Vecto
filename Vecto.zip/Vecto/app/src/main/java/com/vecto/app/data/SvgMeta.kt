package com.vecto.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class SvgMeta(val width: String?, val height: String?, val viewBox: String?) {
    val dimensions: String?
        get() = if (width != null && height != null) "$width × $height px" else null
}

/** Reads only the root <svg> tag (first 64 KB) to show dimensions in the info sheet. */
suspend fun readSvgMeta(context: Context, uri: Uri): SvgMeta? = withContext(Dispatchers.IO) {
    try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(64 * 1024)
            val read = input.read(buffer)
            if (read <= 0) return@use null
            val head = String(buffer, 0, read, Charsets.UTF_8)
            val tag = Regex("<svg\\b[^>]*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .find(head)?.value ?: return@use null

            fun attr(name: String): String? =
                Regex("\\s$name\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
                    .find(tag)?.groupValues?.get(1)?.trim()

            fun number(raw: String?): String? {
                val m = Regex("^([0-9]*\\.?[0-9]+)\\s*(px)?$").find(raw ?: return null) ?: return null
                return m.groupValues[1].removeSuffix(".0")
            }

            val viewBox = attr("viewBox")
            var width = number(attr("width"))
            var height = number(attr("height"))
            if ((width == null || height == null) && viewBox != null) {
                val parts = viewBox.split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
                if (parts.size == 4) {
                    width = width ?: number(parts[2])
                    height = height ?: number(parts[3])
                }
            }
            SvgMeta(width, height, viewBox)
        }
    } catch (e: Exception) {
        null
    }
}
