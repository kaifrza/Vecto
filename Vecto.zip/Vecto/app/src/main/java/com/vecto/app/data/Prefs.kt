package com.vecto.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Tiny SharedPreferences wrapper that exposes everything as StateFlow. */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("vecto_prefs", Context.MODE_PRIVATE)

    private fun readSet(key: String): Set<String> =
        sp.getStringSet(key, emptySet())?.toSet() ?: emptySet()

    private fun writeSet(key: String, value: Set<String>) {
        sp.edit().putStringSet(key, HashSet(value)).apply()
    }

    private val _favorites = MutableStateFlow(readSet("favorites"))
    val favorites: StateFlow<Set<String>> = _favorites.asStateFlow()

    private val _trees = MutableStateFlow(readSet("trees"))
    val trees: StateFlow<Set<String>> = _trees.asStateFlow()

    private val _files = MutableStateFlow(readSet("files"))
    val files: StateFlow<Set<String>> = _files.asStateFlow()

    private val _theme = MutableStateFlow(sp.getInt("theme", 0).coerceIn(0, 2))
    /** 0 = system, 1 = light, 2 = dark */
    val theme: StateFlow<Int> = _theme.asStateFlow()

    private val _sort = MutableStateFlow(
        SortMode.entries.getOrElse(sp.getInt("sort", 0)) { SortMode.NEWEST }
    )
    val sort: StateFlow<SortMode> = _sort.asStateFlow()

    private val _columns = MutableStateFlow(sp.getInt("columns", 3).coerceIn(2, 6))
    val columns: StateFlow<Int> = _columns.asStateFlow()

    private val _fit = MutableStateFlow(sp.getBoolean("fit", true))
    val fit: StateFlow<Boolean> = _fit.asStateFlow()

    private val _viewerBg = MutableStateFlow(sp.getInt("viewer_bg", 0).coerceIn(0, 3))
    /** 0 = theme, 1 = white, 2 = black, 3 = checkerboard */
    val viewerBg: StateFlow<Int> = _viewerBg.asStateFlow()

    fun setFavorites(uris: Collection<String>, value: Boolean) {
        val next = if (value) _favorites.value + uris else _favorites.value - uris.toSet()
        _favorites.value = next
        writeSet("favorites", next)
    }

    fun toggleFavorite(uri: String) = setFavorites(listOf(uri), uri !in _favorites.value)

    fun addTree(uri: String) {
        val next = _trees.value + uri
        _trees.value = next
        writeSet("trees", next)
    }

    fun addFiles(uris: Collection<String>) {
        val next = _files.value + uris
        _files.value = next
        writeSet("files", next)
    }

    fun clearSources() {
        _trees.value = emptySet()
        _files.value = emptySet()
        writeSet("trees", emptySet())
        writeSet("files", emptySet())
    }

    fun setTheme(mode: Int) {
        _theme.value = mode
        sp.edit().putInt("theme", mode).apply()
    }

    fun setSort(mode: SortMode) {
        _sort.value = mode
        sp.edit().putInt("sort", mode.ordinal).apply()
    }

    fun setColumns(count: Int) {
        val v = count.coerceIn(2, 6)
        _columns.value = v
        sp.edit().putInt("columns", v).apply()
    }

    fun setFit(fit: Boolean) {
        _fit.value = fit
        sp.edit().putBoolean("fit", fit).apply()
    }

    fun cycleViewerBg() {
        val v = (_viewerBg.value + 1) % 4
        _viewerBg.value = v
        sp.edit().putInt("viewer_bg", v).apply()
    }
}
