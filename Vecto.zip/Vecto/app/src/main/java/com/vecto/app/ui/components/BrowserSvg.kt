package com.vecto.app.ui.components

import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.util.Base64
import android.webkit.WebView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.viewinterop.AndroidView
import com.vecto.app.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private sealed interface BrowserState {
    data object Loading : BrowserState
    data object Failed : BrowserState
    data class Ready(val html: String) : BrowserState
}

/**
 * Renders the SVG with the system WebView (full browser engine: CSS, filters, masks...).
 * The SVG is shown inside an <img>, so scripts inside the file never run.
 */
@Composable
fun BrowserSvg(uri: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var state by remember(uri) { mutableStateOf<BrowserState>(BrowserState.Loading) }

    LaunchedEffect(uri) {
        val html = withContext(Dispatchers.IO) { buildHtml(context, Uri.parse(uri)) }
        state = if (html == null) BrowserState.Failed else BrowserState.Ready(html)
    }

    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when (val s = state) {
            BrowserState.Loading -> CircularProgressIndicator()
            BrowserState.Failed -> Text(
                stringResource(R.string.browser_load_failed),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            is BrowserState.Ready -> AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        setBackgroundColor(AndroidColor.TRANSPARENT)
                        settings.javaScriptEnabled = false
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        settings.setSupportZoom(true)
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                    }
                },
                update = { web ->
                    // Only reload when the document actually changed (update runs on every recomposition).
                    if (web.tag != s.html) {
                        web.tag = s.html
                        web.loadDataWithBaseURL(null, s.html, "text/html", "utf-8", null)
                    }
                }
            )
        }
    }
}

private fun buildHtml(context: Context, uri: Uri): String? {
    return try {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        if (bytes.isEmpty() || bytes.size > 15_000_000) return null
        val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
        """
        <!doctype html><html><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=8, user-scalable=yes">
        <style>
          html,body{margin:0;height:100%;background:transparent}
          body{display:flex;align-items:center;justify-content:center}
          img{width:100%;height:100%;object-fit:contain}
        </style></head>
        <body><img alt="" src="data:image/svg+xml;base64,$encoded"></body></html>
        """.trimIndent()
    } catch (e: Exception) {
        null
    }
}
