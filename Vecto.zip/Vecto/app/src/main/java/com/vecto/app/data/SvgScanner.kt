package com.vecto.app.data

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import com.vecto.app.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val SVG_MIME = "image/svg+xml"

/**
 * Finds .svg files from three places:
 *  1. MediaStore (needs the media permission) - everything on the phone
 *  2. Folders the user added with the system folder picker
 *  3. Single files the user opened with the system file picker
 */
class SvgScanner(private val context: Context) {

    fun hasMediaPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    suspend fun scan(trees: Set<String>, files: Set<String>): List<SvgItem> = withContext(Dispatchers.IO) {
        val byUri = LinkedHashMap<String, SvgItem>()
        val seenSignature = HashSet<String>()

        fun add(item: SvgItem) {
            if (byUri.containsKey(item.uri)) return
            // The same physical file can be reachable through MediaStore and through a picked folder.
            val signature = "${item.name}|${item.sizeBytes}|${item.modifiedSec}"
            if (!seenSignature.add(signature)) return
            byUri[item.uri] = item
        }

        queryMediaStore().forEach(::add)
        trees.forEach { tree ->
            runCatching { scanTree(Uri.parse(tree)) }.getOrDefault(emptyList()).forEach(::add)
        }
        files.forEach { file ->
            queryDocument(Uri.parse(file))?.let(::add)
        }
        byUri.values.toList()
    }

    private fun queryMediaStore(): List<SvgItem> {
        if (!hasMediaPermission()) return emptyList()
        val collection = MediaStore.Files.getContentUri("external")
        val pathColumn = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.MediaColumns.RELATIVE_PATH
        } else {
            "_data"
        }
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.DATE_ADDED,
            pathColumn
        )
        val selection = "(${MediaStore.Files.FileColumns.MIME_TYPE} = ? OR " +
            "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?) AND ${MediaStore.Files.FileColumns.SIZE} > 0"
        val args = arrayOf(SVG_MIME, "%.svg")
        val internal = context.getString(R.string.internal_storage)
        val out = ArrayList<SvgItem>()
        try {
            context.contentResolver.query(
                collection, projection, selection, args,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val modCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val addCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED)
                val pathCol = c.getColumnIndexOrThrow(pathColumn)
                while (c.moveToNext()) {
                    val name = c.getString(nameCol) ?: continue
                    if (!name.endsWith(".svg", ignoreCase = true)) continue
                    val rawPath = c.getString(pathCol).orEmpty()
                    val folderPath = if (Build.VERSION.SDK_INT >= 29) {
                        rawPath.trim('/')
                    } else {
                        rawPath.substringBeforeLast('/', "")
                    }
                    val folderName = folderPath.substringAfterLast('/').ifEmpty { internal }
                    val modified = c.getLong(modCol).takeIf { it > 0 } ?: c.getLong(addCol)
                    out += SvgItem(
                        uri = ContentUris.withAppendedId(collection, c.getLong(idCol)).toString(),
                        name = name,
                        sizeBytes = c.getLong(sizeCol),
                        modifiedSec = modified,
                        folderKey = "ms:$folderPath",
                        folderName = folderName
                    )
                }
            }
        } catch (e: Exception) {
            // SecurityException / IllegalArgumentException: treat as "nothing found" instead of crashing.
        }
        return out
    }

    private fun scanTree(treeUri: Uri): List<SvgItem> {
        val out = ArrayList<SvgItem>()
        val resolver = context.contentResolver
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )

        fun walk(docId: String, depth: Int) {
            if (depth > 8 || out.size > 20_000) return
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            val folderName = docId.substringAfterLast('/').substringAfterLast(':').ifEmpty { docId }
            val subDirs = ArrayList<String>()
            try {
                resolver.query(children, projection, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2).orEmpty()
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            subDirs += id
                        } else if (mime == SVG_MIME || name.endsWith(".svg", ignoreCase = true)) {
                            out += SvgItem(
                                uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id).toString(),
                                name = name,
                                sizeBytes = c.getLong(3),
                                modifiedSec = c.getLong(4) / 1000,
                                folderKey = "tree:$docId",
                                folderName = folderName
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                return
            }
            subDirs.forEach { walk(it, depth + 1) }
        }

        walk(DocumentsContract.getTreeDocumentId(treeUri), 0)
        return out
    }

    /** Reads name / size / date for a single picked or shared file. Returns null if unreadable. */
    fun queryDocument(uri: Uri): SvgItem? {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (!c.moveToFirst()) return@use null
                val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                val modIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                val name = (if (nameIdx >= 0) c.getString(nameIdx) else null)
                    ?: uri.lastPathSegment
                    ?: context.getString(R.string.unknown_name)
                val size = if (sizeIdx >= 0 && !c.isNull(sizeIdx)) c.getLong(sizeIdx) else 0L
                val modifiedMs = if (modIdx >= 0 && !c.isNull(modIdx)) c.getLong(modIdx) else System.currentTimeMillis()
                SvgItem(
                    uri = uri.toString(),
                    name = name,
                    sizeBytes = size,
                    modifiedSec = modifiedMs / 1000,
                    folderKey = "picked",
                    folderName = context.getString(R.string.opened_files)
                )
            }
        } catch (e: Exception) {
            null
        }
    }
}
