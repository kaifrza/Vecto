package com.vecto.app.ui

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.vecto.app.data.SvgItem

/** Opens the system share sheet for one or more SVG files. Returns false if nothing can handle it. */
fun shareItems(context: Context, items: List<SvgItem>): Boolean {
    if (items.isEmpty()) return false
    val uris = ArrayList(items.map { it.parsedUri })
    val intent = if (uris.size == 1) {
        Intent(Intent.ACTION_SEND).apply {
            type = "image/svg+xml"
            putExtra(Intent.EXTRA_STREAM, uris[0])
        }
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/svg+xml"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
    }
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    val clip = ClipData.newRawUri(null, uris[0])
    for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
    intent.clipData = clip
    return try {
        context.startActivity(Intent.createChooser(intent, null))
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }
}

fun openAppSettings(context: Context) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        // nothing sensible to do
    }
}
