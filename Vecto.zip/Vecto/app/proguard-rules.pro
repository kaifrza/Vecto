# Coil + AndroidSVG: keep what reflection/XML parsing needs
-dontwarn com.caverock.androidsvg.**
-keep class com.caverock.androidsvg.** { *; }
-dontwarn org.xmlpull.**
-dontwarn javax.xml.**
