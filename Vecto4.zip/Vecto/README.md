# Vecto – modern SVG viewer for Android

Photos-app style gallery for `.svg` files: date-grouped grid, albums, favorites, search,
multi-select + share, pinch/double-tap zoom, swipe between files, transparent-background
checkerboard, info sheet, light/dark theme.

## Features
- Finds every `.svg` on the phone (media permission) or from folders/files you add yourself
- Opens `.svg` straight from any file manager (“Open with Vecto”) or the share sheet
- Standard engine (fast) + **Browser engine** toggle for SVGs that use filters/CSS the standard engine can't draw
- Zoom up to 40x with razor-sharp vector re-rendering; custom viewer background colors (swatches + HSV sliders)
- Export as PNG/JPG (256-4096 px, transparent/white/black/viewer background) into Pictures/Vecto (Android 10+)
- View SVG code with highlighting + copy
- Rename / delete files (Android shows its own permission dialog when needed; folders added before v1.2 must be re-added once to allow it)
- Pinch on the grid to change columns, fast-scroll handle with date bubble
- Home-screen widget: long-press home screen > Widgets > Vecto
- Colors: palette of every color in the SVG (HEX copy), change a color everywhere with live preview, save a recolored copy (original untouched)
- Compare two SVGs side by side or stacked with linked zoom (select 2 files > ⋮ > Compare)
- Paste SVG code from the clipboard and preview/save it (menu > Paste SVG code)
- Your own albums and tags (⋮ in selection bar or viewer > More), tag filter chips on the Photos tab
- Recycle bin: deleted files are kept 30 days and can be restored (menu > Recycle bin)
- Info sheet shows the full file path
- Install the **release** APK for the smoothest scrolling (debug builds of Compose apps are much slower)
- Fixed signing key bundled → every new APK installs over the old one (no uninstall needed)

## Build the APK with GitHub Actions
1. Create a GitHub repo.
2. Upload **two things** to it: `build-apk.yml` (inside `.github/workflows/`) and this project's `.zip` (anywhere, root is fine). Do **not** unzip it.
3. Actions tab → **Build APK** → it runs automatically on push, or press *Run workflow*.
4. Download the APK from the **Releases** page (`latest-apk`) or from the run's **Artifacts**.

The workflow picks the newest zip (by last commit) that contains a Gradle project, extracts it
only inside the build machine, and leaves your repo untouched. Upload a newer zip later → it builds that one.

## Optional: your own release key
Add GitHub secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Never commit your own keystore. If you switch keys you must uninstall the old app once.

## Local build
`gradle assembleDebug` (Gradle 8.9, JDK 17, Android SDK 34).

## Customize
Colors: `ui/theme/Theme.kt` · App name: `res/values/strings.xml` · Package id: `app/build.gradle.kts`.

## Folders
`data/` scanning, prefs · `ui/components/` grid, tiles, zoom · `ui/screens/` Home, Viewer, sheets
