package com.vecto.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vecto.app.R

/** Paste (or type) SVG code, then preview it in the viewer or save it as a file. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasteSheet(onPreview: (String) -> Unit, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var code by remember {
        mutableStateOf(clipboard.getText()?.text?.takeIf { it.contains("<svg", ignoreCase = true) }.orEmpty())
    }
    val valid = code.contains("<svg", ignoreCase = true)

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
                .navigationBarsPadding()
                .imePadding()
        ) {
            Text(stringResource(R.string.paste_title), style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = code,
                onValueChange = { code = it },
                placeholder = { Text(stringResource(R.string.paste_hint)) },
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                minLines = 6,
                maxLines = 10,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(onClick = { code = clipboard.getText()?.text.orEmpty() }) {
                    Text(stringResource(R.string.paste_from_clipboard))
                }
                Row(Modifier.weight(1f)) {}
                FilledTonalButton(enabled = valid, onClick = { onSave(code); onDismiss() }) {
                    Text(stringResource(R.string.save))
                }
                Button(enabled = valid, onClick = { onPreview(code); onDismiss() }) {
                    Text(stringResource(R.string.paste_preview))
                }
            }
        }
    }
}
