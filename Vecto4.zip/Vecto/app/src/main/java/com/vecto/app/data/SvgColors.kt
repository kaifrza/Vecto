package com.vecto.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

data class SvgColor(val hex: String, val count: Int)

/** Finds the colors used in an SVG (hex, rgb(), common color names) and swaps them. */
object SvgColors {
    private val named = mapOf(
        "red" to "#FF0000", "blue" to "#0000FF", "green" to "#008000", "black" to "#000000",
        "white" to "#FFFFFF", "gray" to "#808080", "grey" to "#808080", "yellow" to "#FFFF00",
        "orange" to "#FFA500", "purple" to "#800080", "pink" to "#FFC0CB", "brown" to "#A52A2A",
        "cyan" to "#00FFFF", "magenta" to "#FF00FF", "lime" to "#00FF00", "navy" to "#000080",
        "teal" to "#008080", "maroon" to "#800000", "silver" to "#C0C0C0", "gold" to "#FFD700"
    )

    // '#abc' that is really a reference (url(#a), href="#a", id="a") is not a color.
    private val hexRegex = Regex(
        "(?<!url\\()(?<!url\\(')(?<!url\\(\")(?<!href=\")(?<!href=')(?<!id=\")(?<!id=')" +
            "#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{4}|[0-9a-fA-F]{3})(?![0-9a-zA-Z_-])"
    )
    private val rgbRegex = Regex(
        "rgba?\\(\\s*(\\d{1,3})\\s*,\\s*(\\d{1,3})\\s*,\\s*(\\d{1,3})\\s*(?:,\\s*([0-9.]+)\\s*)?\\)",
        RegexOption.IGNORE_CASE
    )
    private val namedRegex = Regex(
        "((?:fill|stroke|stop-color|flood-color|color)\\s*[=:]\\s*[\"']?\\s*)(" +
            named.keys.joinToString("|") + ")(?![A-Za-z0-9-])",
        RegexOption.IGNORE_CASE
    )

    private fun normalizeHex(body: String): String {
        val six = when (body.length) {
            3, 4 -> body.take(3).map { "$it$it" }.joinToString("")
            else -> body.take(6)
        }
        return "#" + six.uppercase(Locale.ROOT)
    }

    private fun rgbToHex(r: Int, g: Int, b: Int): String =
        String.format(Locale.ROOT, "#%02X%02X%02X", r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))

    /** Colors in the file, most used first. Hex format is always #RRGGBB (alpha ignored). */
    fun extract(text: String): List<SvgColor> {
        val counts = LinkedHashMap<String, Int>()
        fun bump(hex: String) { counts[hex] = (counts[hex] ?: 0) + 1 }
        hexRegex.findAll(text).forEach { bump(normalizeHex(it.groupValues[1])) }
        rgbRegex.findAll(text).forEach {
            bump(rgbToHex(it.groupValues[1].toInt(), it.groupValues[2].toInt(), it.groupValues[3].toInt()))
        }
        namedRegex.findAll(text).forEach { named[it.groupValues[2].lowercase(Locale.ROOT)]?.let(::bump) }
        return counts.entries.sortedByDescending { it.value }.take(40).map { SvgColor(it.key, it.value) }
    }

    /** [mapping] is original #RRGGBB -> new #RRGGBB. Alpha parts are kept. */
    fun recolor(text: String, mapping: Map<String, String>): String {
        if (mapping.isEmpty()) return text
        var out = hexRegex.replace(text) { m ->
            val body = m.groupValues[1]
            val to = mapping[normalizeHex(body)] ?: return@replace m.value
            val alpha = when (body.length) {
                8 -> body.substring(6)
                4 -> body[3].toString().repeat(2)
                else -> ""
            }
            to + alpha
        }
        out = rgbRegex.replace(out) { m ->
            val key = rgbToHex(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt())
            val to = mapping[key] ?: return@replace m.value
            val alpha = m.groupValues[4]
            if (alpha.isEmpty()) {
                to
            } else {
                val c = android.graphics.Color.parseColor(to)
                "rgba(${android.graphics.Color.red(c)},${android.graphics.Color.green(c)},${android.graphics.Color.blue(c)},$alpha)"
            }
        }
        out = namedRegex.replace(out) { m ->
            val key = named[m.groupValues[2].lowercase(Locale.ROOT)] ?: return@replace m.value
            val to = mapping[key] ?: return@replace m.value
            m.groupValues[1] + to
        }
        return out
    }
}

/** Reads an SVG as text (null if it is missing or larger than 4 MB). */
suspend fun readSvgText(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
    try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val bytes = input.readBytes()
            if (bytes.size > 4_000_000) null else String(bytes, Charsets.UTF_8)
        }
    } catch (e: Exception) {
        null
    }
}
