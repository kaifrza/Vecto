package com.vecto.app.ui.screens

import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.vecto.app.R
import com.vecto.app.data.SvgItem
import com.vecto.app.data.SvgMeta
import com.vecto.app.data.readSvgMeta
import com.vecto.app.ui.components.CheckerBoard
import com.vecto.app.ui.components.ZoomState

/** Two SVGs next to each other. Zoom and pan are linked, so you can inspect the same spot in both. */
@Composable
fun CompareScreen(a: SvgItem, b: SvgItem, bgMode: Int, bgColor: Int, onClose: () -> Unit) {
    var swapped by rememberSaveable { mutableStateOf(false) }
    var sideBySide by rememberSaveable { mutableStateOf(true) }
    val first = if (swapped) b else a
    val second = if (swapped) a else b
    val zoom = remember { ZoomState() }
    val colors = MaterialTheme.colorScheme

    BackHandler(onBack = onClose)

    val canvas = when (bgMode) {
        1, 3 -> Color.White
        2 -> Color.Black
        4 -> Color(bgColor)
        else -> colors.background
    }

    Surface(Modifier.fillMaxSize(), color = colors.background) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.back))
                }
                Text(
                    stringResource(R.string.compare_title),
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { swapped = !swapped }) { Text(stringResource(R.string.compare_swap)) }
                TextButton(onClick = { sideBySide = !sideBySide }) {
                    Text(stringResource(if (sideBySide) R.string.compare_stack else R.string.compare_side))
                }
            }
            if (sideBySide) {
                Row(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                ) {
                    Pane(first, zoom, canvas, bgMode == 3, Modifier.weight(1f).fillMaxHeight())
                    Box(Modifier.width(2.dp).fillMaxHeight().background(colors.outlineVariant))
                    Pane(second, zoom, canvas, bgMode == 3, Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                ) {
                    Pane(first, zoom, canvas, bgMode == 3, Modifier.weight(1f).fillMaxWidth())
                    Box(Modifier.height(2.dp).fillMaxWidth().background(colors.outlineVariant))
                    Pane(second, zoom, canvas, bgMode == 3, Modifier.weight(1f).fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun Pane(item: SvgItem, zoom: ZoomState, canvas: Color, checker: Boolean, modifier: Modifier) {
    val context = LocalContext.current
    val meta by produceState<SvgMeta?>(null, item.uri) { value = readSvgMeta(context, item.parsedUri) }
    Box(modifier.background(canvas)) {
        if (checker) CheckerBoard(Modifier.fillMaxSize())
        ZoomableSvg(item = item, zoom = zoom, onTap = {}, onTryBrowser = {})
        Surface(
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(8.dp)
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    item.title,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val size = if (item.sizeBytes > 0) Formatter.formatShortFileSize(context, item.sizeBytes) else ""
                val dims = meta?.dimensions.orEmpty()
                Text(
                    listOf(size, dims).filter { it.isNotEmpty() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
