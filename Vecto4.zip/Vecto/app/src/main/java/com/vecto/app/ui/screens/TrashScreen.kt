package com.vecto.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vecto.app.R
import com.vecto.app.data.SvgItem
import com.vecto.app.ui.MainViewModel
import com.vecto.app.ui.components.EmptyState
import com.vecto.app.ui.components.PhotoGrid
import com.vecto.app.ui.components.buildEntries

/** Recycle bin: deleted files are kept for 30 days and can be restored. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrashScreen(vm: MainViewModel) {
    val entries by vm.trash.entries.collectAsStateWithLifecycle()
    val columns by vm.prefs.columns.collectAsStateWithLifecycle()
    val fit by vm.prefs.fit.collectAsStateWithLifecycle()

    // folderKey carries the recycle-bin id so we can find the entry again.
    val items = remember(entries) {
        entries.sortedByDescending { it.deletedAt }.map { e ->
            SvgItem(
                uri = vm.trash.file(e).toUri().toString(),
                name = e.name,
                sizeBytes = e.sizeBytes,
                modifiedSec = e.deletedAt / 1000,
                folderKey = e.id,
                folderName = "",
                path = e.originalPath
            )
        }
    }
    val gridEntries = remember(items) { buildEntries(items, grouped = false, today = "", yesterday = "") }
    var target by remember { mutableStateOf<SvgItem?>(null) }
    var confirmEmpty by remember { mutableStateOf(false) }

    BackHandler(onBack = vm::closeTrash)

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::closeTrash) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.back))
                }
                Text(
                    stringResource(R.string.trash_title),
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
                TextButton(enabled = items.isNotEmpty(), onClick = { confirmEmpty = true }) {
                    Text(stringResource(R.string.trash_empty_action))
                }
            }
            Text(
                stringResource(R.string.trash_info),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            if (items.isEmpty()) {
                EmptyState(
                    title = stringResource(R.string.trash_empty_title),
                    body = stringResource(R.string.trash_empty_body)
                )
            } else {
                PhotoGrid(
                    entries = gridEntries,
                    columns = columns,
                    fit = fit,
                    selection = emptySet(),
                    favorites = emptySet(),
                    onOpen = { index -> target = items[index] },
                    onToggleSelect = { target = it },
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 2.dp, end = 2.dp, bottom = 24.dp)
                )
            }
        }
    }

    target?.let { item ->
        ModalBottomSheet(onDismissRequest = { target = null }) {
            Column(Modifier.padding(bottom = 16.dp).navigationBarsPadding()) {
                Text(
                    item.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                )
                Text(
                    item.path,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp)
                )
                SheetRow(Icons.Rounded.Refresh, stringResource(R.string.trash_restore), false) {
                    vm.restoreFromTrash(listOf(item.folderKey))
                    target = null
                }
                SheetRow(Icons.Rounded.Delete, stringResource(R.string.trash_delete_forever), true) {
                    vm.deleteForever(listOf(item.folderKey))
                    target = null
                }
            }
        }
    }

    if (confirmEmpty) {
        ConfirmDialog(
            title = stringResource(R.string.trash_empty_action),
            body = stringResource(R.string.trash_empty_confirm),
            confirmLabel = stringResource(R.string.delete_confirm),
            onConfirm = { confirmEmpty = false; vm.emptyTrash() },
            onDismiss = { confirmEmpty = false }
        )
    }
}

@Composable
private fun SheetRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, danger: Boolean, onClick: () -> Unit) {
    val color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(16.dp)
    ) {
        Icon(icon, contentDescription = null, tint = color)
        Text(label, style = MaterialTheme.typography.bodyLarge, color = color)
    }
}
