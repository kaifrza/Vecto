package com.vecto.app.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.vecto.app.R
import com.vecto.app.data.SvgItem
import com.vecto.app.ui.Exporter
import kotlinx.coroutines.launch

private val Sizes = listOf(256, 512, 1024, 2048, 4096)

/**
 * Export the SVG as PNG or JPG at a chosen size.
 * [viewerColor] is the viewer's custom background (ARGB) if one is active, otherwise null.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportSheet(item: SvgItem, viewerColor: Int?, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var jpg by remember { mutableStateOf(false) }
    var size by remember { mutableIntStateOf(1024) }
    var bg by remember { mutableIntStateOf(0) } // 0 transparent, 1 white, 2 black, 3 viewer color
    var busy by remember { mutableStateOf(false) }

    fun run(share: Boolean) {
        if (busy) return
        busy = true
        val background = when (bg) {
            1 -> android.graphics.Color.WHITE
            2 -> android.graphics.Color.BLACK
            3 -> viewerColor
            else -> null
        }
        scope.launch {
            try {
                val uri = Exporter.export(context, item, size, background, jpg)
                Toast.makeText(context, context.getString(R.string.export_saved), Toast.LENGTH_SHORT).show()
                if (share) {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = if (jpg) "image/jpeg" else "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(send, null))
                }
                onDismiss()
            } catch (e: Exception) {
                busy = false
                Toast.makeText(context, e.message ?: context.getString(R.string.export_failed), Toast.LENGTH_LONG).show()
            }
        }
    }

    ModalBottomSheet(onDismissRequest = { if (!busy) onDismiss() }) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
                .navigationBarsPadding()
        ) {
            Text(stringResource(R.string.export_title), style = MaterialTheme.typography.titleLarge)

            Label(stringResource(R.string.export_format))
            Chips {
                FilterChip(!jpg, { jpg = false }, { Text("PNG") })
                FilterChip(jpg, { jpg = true }, { Text("JPG") })
            }

            Label(stringResource(R.string.export_size))
            Chips {
                Sizes.forEach { s -> FilterChip(size == s, { size = s }, { Text(s.toString()) }) }
            }

            Label(stringResource(R.string.export_background))
            Chips {
                if (!jpg) FilterChip(bg == 0, { bg = 0 }, { Text(stringResource(R.string.export_bg_transparent)) })
                FilterChip(bg == 1 || (jpg && bg == 0), { bg = 1 }, { Text(stringResource(R.string.export_bg_white)) })
                FilterChip(bg == 2, { bg = 2 }, { Text(stringResource(R.string.export_bg_black)) })
                if (viewerColor != null) {
                    FilterChip(bg == 3, { bg = 3 }, { Text(stringResource(R.string.export_bg_current)) })
                }
            }
            if (jpg) {
                Text(
                    stringResource(R.string.export_jpg_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (busy) {
                    CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                } else {
                    FilledTonalButton(onClick = { run(false) }) { Text(stringResource(R.string.export_save)) }
                    Button(onClick = { run(true) }) { Text(stringResource(R.string.export_share)) }
                }
            }
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
    )
}

@Composable
private fun Chips(content: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}
