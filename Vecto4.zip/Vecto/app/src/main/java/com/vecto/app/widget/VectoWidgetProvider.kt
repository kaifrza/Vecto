package com.vecto.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.View
import android.widget.RemoteViews
import com.vecto.app.MainActivity
import com.vecto.app.R
import com.vecto.app.data.Prefs
import com.vecto.app.data.SvgItem
import com.vecto.app.data.SvgScanner
import com.vecto.app.ui.components.loadSvgDoc
import com.vecto.app.ui.components.renderDetail
import kotlinx.coroutines.runBlocking
import kotlin.math.min

/**
 * Home-screen widget: shows a random favorite SVG (or one of your newest SVGs if you have no favorites).
 * Tap the picture to open it in Vecto, tap the arrow for another one.
 */
class VectoWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        refresh(context, appWidgetManager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_NEXT) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, VectoWidgetProvider::class.java))
            refresh(context, manager, ids)
        } else {
            super.onReceive(context, intent)
        }
    }

    private fun refresh(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        Thread {
            try {
                val views = build(context)
                ids.forEach { manager.updateAppWidget(it, views) }
            } catch (e: Exception) {
                // keep the previous widget content
            } finally {
                pending.finish()
            }
        }.start()
    }

    private fun build(context: Context): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_vecto)
        val prefs = Prefs(context)
        val items = runBlocking { SvgScanner(context).scan(prefs.trees.value, prefs.files.value) }
        val favorites = prefs.favorites.value
        val pool = items.filter { it.uri in favorites }
            .ifEmpty { items.sortedByDescending { it.modifiedSec }.take(30) }

        var shown: SvgItem? = null
        var bitmap: Bitmap? = null
        for (item in pool.shuffled().take(5)) {
            bitmap = renderThumb(context, item)
            if (bitmap != null) {
                shown = item
                break
            }
        }

        val openIntent = if (shown != null) {
            Intent(context, MainActivity::class.java)
                .setAction(Intent.ACTION_VIEW)
                .setDataAndType(shown.parsedUri, "image/svg+xml")
        } else {
            Intent(context, MainActivity::class.java)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        views.setOnClickPendingIntent(
            R.id.widget_root,
            PendingIntent.getActivity(context, shown?.uri.hashCode(), openIntent, flags)
        )
        views.setOnClickPendingIntent(
            R.id.widget_next,
            PendingIntent.getBroadcast(
                context, 0,
                Intent(context, VectoWidgetProvider::class.java).setAction(ACTION_NEXT),
                flags
            )
        )

        if (bitmap != null) {
            views.setImageViewBitmap(R.id.widget_image, bitmap)
            views.setViewVisibility(R.id.widget_image, View.VISIBLE)
            views.setViewVisibility(R.id.widget_empty, View.GONE)
        } else {
            views.setViewVisibility(R.id.widget_image, View.GONE)
            views.setViewVisibility(R.id.widget_empty, View.VISIBLE)
        }
        return views
    }

    private fun renderThumb(context: Context, item: SvgItem): Bitmap? {
        val side = 400
        val pad = 24f
        val doc = runBlocking { loadSvgDoc(context, item.parsedUri) } ?: return null
        val fit = min((side - 2 * pad) / doc.width, (side - 2 * pad) / doc.height)
        val cw = doc.width * fit
        val ch = doc.height * fit
        return renderDetail(doc, side, side, (side - cw) / 2f, (side - ch) / 2f, cw, ch)
    }

    companion object {
        const val ACTION_NEXT = "com.vecto.app.widget.NEXT"
    }
}
