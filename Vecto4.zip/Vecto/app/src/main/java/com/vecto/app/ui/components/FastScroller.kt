package com.vecto.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Drag handle on the right edge for quickly jumping through a long grid. Appears while scrolling,
 * shows the date section you are dragging over, fades away when idle.
 */
@Composable
fun FastScroller(
    state: LazyGridState,
    entries: List<GridEntry>,
    indexOffset: Int,
    modifier: Modifier = Modifier
) {
    val total by remember { derivedStateOf { state.layoutInfo.totalItemsCount } }
    if (total < 40) return

    val scope = rememberCoroutineScope()
    val thumbHeightPx = with(LocalDensity.current) { 56.dp.toPx() }
    var trackHeight by remember { mutableIntStateOf(0) }
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    var visible by remember { mutableStateOf(false) }
    var scrollJob by remember { mutableStateOf<Job?>(null) }

    val listFraction by remember {
        derivedStateOf {
            val info = state.layoutInfo
            val denominator = (info.totalItemsCount - info.visibleItemsInfo.size).coerceAtLeast(1)
            (state.firstVisibleItemIndex.toFloat() / denominator).coerceIn(0f, 1f)
        }
    }
    val fraction = if (dragging) dragFraction else listFraction

    val scrolling = state.isScrollInProgress || dragging
    LaunchedEffect(scrolling) {
        if (scrolling) {
            visible = true
        } else {
            delay(1200)
            visible = false
        }
    }

    val headers = remember(entries, indexOffset) {
        entries.mapIndexedNotNull { i, e -> if (e is GridEntry.Header) (i + indexOffset) to e.title else null }
    }

    Box(
        modifier
            .fillMaxHeight()
            .width(180.dp)
            .onSizeChanged { trackHeight = it.height }
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(120)),
            exit = fadeOut(tween(300)),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset {
                    val range = (trackHeight - thumbHeightPx).coerceAtLeast(0f)
                    IntOffset(0, (fraction * range).roundToInt())
                }
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (dragging) {
                    val labelIndex = (fraction * (total - 1)).roundToInt()
                    val label = headers.lastOrNull { it.first <= labelIndex }?.second
                        ?: "${(labelIndex - indexOffset + 1).coerceAtLeast(1)}"
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            label,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
                Box(
                    Modifier
                        .width(36.dp)
                        .height(56.dp)
                        .pointerInput(Unit) {
                            detectVerticalDragGestures(
                                onDragStart = {
                                    dragging = true
                                    dragFraction = listFraction
                                },
                                onDragEnd = { dragging = false },
                                onDragCancel = { dragging = false }
                            ) { change, dy ->
                                change.consume()
                                val range = (trackHeight - thumbHeightPx).coerceAtLeast(1f)
                                dragFraction = (dragFraction + dy / range).coerceIn(0f, 1f)
                                val target = (dragFraction * (total - 1)).roundToInt()
                                scrollJob?.cancel()
                                scrollJob = scope.launch { state.scrollToItem(target) }
                            }
                        },
                    contentAlignment = Alignment.CenterEnd
                ) {
                    Box(
                        Modifier
                            .padding(end = 4.dp)
                            .width(6.dp)
                            .height(56.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
            }
        }
    }
}

/** Two-finger pinch on the grid: spread = bigger tiles (fewer columns), pinch = more columns. */
@Composable
fun Modifier.pinchColumns(columns: Int, onChange: (Int) -> Unit): Modifier {
    val current by rememberUpdatedState(columns)
    val callback by rememberUpdatedState(onChange)
    return this.pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var accumulated = 1f
            do {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                if (event.changes.count { it.pressed } >= 2) {
                    accumulated *= event.calculateZoom()
                    if (accumulated > 1.3f) {
                        callback((current - 1).coerceAtLeast(2))
                        accumulated = 1f
                    } else if (accumulated < 0.77f) {
                        callback((current + 1).coerceAtMost(6))
                        accumulated = 1f
                    }
                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                }
            } while (event.changes.any { it.pressed })
        }
    }
}
