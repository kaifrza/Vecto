package com.vecto.app.ui

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.vecto.app.R

/** Saves SVG files into Pictures/Vecto (Android 10+). Throws IllegalStateException with a readable message. */
object SvgFiles {
    fun saveBytes(context: Context, name: String, bytes: ByteArray): Uri {
        if (Build.VERSION.SDK_INT < 29) error(context.getString(R.string.export_needs_android10))
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, if (name.endsWith(".svg", true)) name else "$name.svg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/svg+xml")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Vecto")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = resolver.insert(collection, values) ?: error(context.getString(R.string.export_failed))
        try {
            resolver.openOutputStream(uri)?.use { it.write(bytes) } ?: error(context.getString(R.string.export_failed))
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return uri
    }

    fun saveText(context: Context, name: String, text: String): Uri = saveBytes(context, name, text.toByteArray(Charsets.UTF_8))
}
