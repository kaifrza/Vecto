package com.vecto.app.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.vecto.app.R
import com.vecto.app.data.SvgItem
import com.vecto.app.ui.components.loadSvgDoc
import com.vecto.app.ui.components.renderExport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

object Exporter {

    /**
     * Renders [item] so its longest side is [longestSide] px and saves it to Pictures/Vecto.
     * Throws IllegalStateException with a user-readable message on failure.
     */
    suspend fun export(
        context: Context,
        item: SvgItem,
        longestSide: Int,
        background: Int?,
        jpg: Boolean
    ): Uri {
        if (Build.VERSION.SDK_INT < 29) error(context.getString(R.string.export_needs_android10))
        val doc = loadSvgDoc(context, item.parsedUri) ?: error(context.getString(R.string.export_failed))

        val scale = longestSide / max(doc.width, doc.height)
        val w = (doc.width * scale).roundToInt().coerceIn(1, 8192)
        val h = (doc.height * scale).roundToInt().coerceIn(1, 8192)
        if (w.toLong() * h * 4L > 300_000_000L) error(context.getString(R.string.export_too_large))

        val fill = if (jpg) (background ?: android.graphics.Color.WHITE) else background
        val bitmap = withContext(Dispatchers.Default) { renderExport(doc, w, h, fill) }
            ?: error(context.getString(R.string.export_too_large))

        return withContext(Dispatchers.IO) {
            try {
                save(context, bitmap, "${item.title}_${w}x$h", jpg)
            } finally {
                bitmap.recycle()
            }
        }
    }

    private fun save(context: Context, bitmap: Bitmap, baseName: String, jpg: Boolean): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, baseName + if (jpg) ".jpg" else ".png")
            put(MediaStore.MediaColumns.MIME_TYPE, if (jpg) "image/jpeg" else "image/png")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Vecto")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = resolver.insert(collection, values) ?: error(context.getString(R.string.export_failed))
        try {
            resolver.openOutputStream(uri)?.use { out ->
                val format = if (jpg) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG
                if (!bitmap.compress(format, 95, out)) error(context.getString(R.string.export_failed))
            } ?: error(context.getString(R.string.export_failed))
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return uri
    }
}
