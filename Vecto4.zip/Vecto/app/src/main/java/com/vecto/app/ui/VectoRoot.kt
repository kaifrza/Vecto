package com.vecto.app.ui

import android.Manifest
import android.app.Activity
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.app.ActivityCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vecto.app.R
import com.vecto.app.ui.screens.CompareScreen
import com.vecto.app.ui.screens.HomeScreen
import com.vecto.app.ui.screens.TrashScreen
import com.vecto.app.ui.screens.ViewerScreen

private val SvgMimeTypes = arrayOf("image/svg+xml", "text/xml", "application/xml", "application/octet-stream")

@Composable
fun VectoRoot(vm: MainViewModel) {
    val context = LocalContext.current
    val activity = context as? Activity
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_IMAGES
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    var asked by rememberSaveable { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refresh() }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.addFolder(uri)
    }
    val filesLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.addFiles(uris)
    }

    // Android asks the user before deleting / renaming files that other apps own.
    val consentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        vm.onConsentResult(result.resultCode == Activity.RESULT_OK)
    }
    LaunchedEffect(Unit) {
        vm.consentRequests.collect { sender ->
            consentLauncher.launch(IntentSenderRequest.Builder(sender).build())
        }
    }

    val requestAccess: () -> Unit = {
        val blocked = asked && activity != null &&
            !ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)
        if (blocked) {
            openAppSettings(context)
        } else {
            asked = true
            permissionLauncher.launch(permission)
        }
    }

    val viewerOpen by vm.viewerOpen.collectAsStateWithLifecycle()
    val viewer by vm.viewer.collectAsStateWithLifecycle()
    val favorites by vm.prefs.favorites.collectAsStateWithLifecycle()
    val bgMode by vm.prefs.viewerBg.collectAsStateWithLifecycle()
    val bgColor by vm.prefs.viewerBgColor.collectAsStateWithLifecycle()
    val tagsMap by vm.collections.tags.collectAsStateWithLifecycle()
    val albumsMap by vm.collections.albums.collectAsStateWithLifecycle()
    val comparePair by vm.compare.collectAsStateWithLifecycle()
    val trashOpen by vm.trashOpen.collectAsStateWithLifecycle()
    val shareFailed = stringResource(R.string.msg_share_failed)
    val visibleState = remember { MutableTransitionState(viewerOpen) }
    visibleState.targetState = viewerOpen

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        HomeScreen(
            vm = vm,
            onRequestAccess = requestAccess,
            onAddFolder = { folderLauncher.launch(null) },
            onOpenFiles = { filesLauncher.launch(SvgMimeTypes) }
        )

        AnimatedVisibility(
            visibleState = visibleState,
            enter = fadeIn(tween(200)) + scaleIn(tween(260, easing = FastOutSlowInEasing), initialScale = 0.92f),
            exit = fadeOut(tween(160)) + scaleOut(tween(200), targetScale = 0.96f)
        ) {
            viewer?.let { v ->
                key(v.nonce) {
                    ViewerScreen(
                        state = v,
                        favorites = favorites,
                        bgMode = bgMode,
                        bgColor = bgColor,
                        onBgMode = vm.prefs::setViewerBg,
                        tags = tagsMap,
                        allTags = tagsMap.values.flatten().toSortedSet().toList(),
                        albumNames = albumsMap.keys.toList(),
                        onToggleTag = { item, tag, add -> vm.toggleTag(listOf(item), tag, add) },
                        onAddToAlbum = { item, name -> vm.addToAlbum(name, listOf(item)) },
                        onCreateAlbum = { item, name -> vm.createAlbum(name, listOf(item)) },
                        onBgColor = vm.prefs::setViewerBgColor,
                        onToggleFavorite = vm::toggleFavorite,
                        onDelete = { item -> vm.deleteItems(listOf(item)) },
                        onRename = { item, name -> vm.renameItem(item, name) },
                        onShare = { item ->
                            if (!shareItems(context, listOf(item))) vm.postMessage(shareFailed)
                        },
                        onClose = {
                            if (v.external) activity?.finish() else vm.closeViewer()
                        }
                    )
                }
            }
        }

        comparePair?.let { (a, b) ->
            CompareScreen(a = a, b = b, bgMode = bgMode, bgColor = bgColor, onClose = vm::closeCompare)
        }
        if (trashOpen) TrashScreen(vm)
    }
}
