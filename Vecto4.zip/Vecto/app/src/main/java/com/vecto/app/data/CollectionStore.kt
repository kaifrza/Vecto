package com.vecto.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Your own albums and tags. Stored on the phone as one small JSON document. */
class CollectionStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("vecto_collections", Context.MODE_PRIVATE)

    private val _albums = MutableStateFlow<Map<String, Set<String>>>(emptyMap())
    /** album name -> file uris (insertion ordered) */
    val albums: StateFlow<Map<String, Set<String>>> = _albums.asStateFlow()

    private val _tags = MutableStateFlow<Map<String, Set<String>>>(emptyMap())
    /** file uri -> tags */
    val tags: StateFlow<Map<String, Set<String>>> = _tags.asStateFlow()

    init {
        try {
            val root = JSONObject(sp.getString("data", "{}") ?: "{}")
            val albums = LinkedHashMap<String, Set<String>>()
            root.optJSONObject("albums")?.let { obj ->
                for (name in obj.keys()) albums[name] = readSet(obj.getJSONArray(name))
            }
            val tags = LinkedHashMap<String, Set<String>>()
            root.optJSONObject("tags")?.let { obj ->
                for (uri in obj.keys()) tags[uri] = readSet(obj.getJSONArray(uri))
            }
            _albums.value = albums
            _tags.value = tags
        } catch (e: Exception) {
            // corrupted data: start empty instead of crashing
        }
    }

    private fun readSet(array: JSONArray): Set<String> {
        val out = LinkedHashSet<String>()
        for (i in 0 until array.length()) out += array.getString(i)
        return out
    }

    private fun save() {
        val root = JSONObject()
        val albums = JSONObject()
        _albums.value.forEach { (name, uris) -> albums.put(name, JSONArray(uris.toList())) }
        val tags = JSONObject()
        _tags.value.forEach { (uri, set) -> if (set.isNotEmpty()) tags.put(uri, JSONArray(set.toList())) }
        root.put("albums", albums)
        root.put("tags", tags)
        sp.edit().putString("data", root.toString()).apply()
    }

    fun normalizeTag(raw: String): String? {
        val t = raw.trim().removePrefix("#").trim().lowercase().replace(Regex("\\s+"), "-")
        return t.take(24).ifEmpty { null }
    }

    // ----- albums -----

    fun createAlbum(rawName: String): String? {
        val name = rawName.trim().take(40)
        if (name.isEmpty()) return null
        if (!_albums.value.containsKey(name)) {
            _albums.value = LinkedHashMap(_albums.value).also { it[name] = emptySet() }
            save()
        }
        return name
    }

    fun renameAlbum(old: String, rawNew: String): Boolean {
        val new = rawNew.trim().take(40)
        if (new.isEmpty() || (new != old && _albums.value.containsKey(new))) return false
        val next = LinkedHashMap<String, Set<String>>()
        _albums.value.forEach { (k, v) -> next[if (k == old) new else k] = v }
        _albums.value = next
        save()
        return true
    }

    fun deleteAlbum(name: String) {
        _albums.value = LinkedHashMap(_albums.value).also { it.remove(name) }
        save()
    }

    fun addToAlbum(name: String, uris: Collection<String>) {
        val current = _albums.value[name] ?: return
        _albums.value = LinkedHashMap(_albums.value).also { it[name] = LinkedHashSet(current).also { s -> s.addAll(uris) } }
        save()
    }

    fun removeFromAlbum(name: String, uris: Collection<String>) {
        val current = _albums.value[name] ?: return
        _albums.value = LinkedHashMap(_albums.value).also { it[name] = current - uris.toSet() }
        save()
    }

    // ----- tags -----

    fun addTag(uris: Collection<String>, rawTag: String) {
        val tag = normalizeTag(rawTag) ?: return
        val next = LinkedHashMap(_tags.value)
        uris.forEach { next[it] = (next[it] ?: emptySet()) + tag }
        _tags.value = next
        save()
    }

    fun removeTag(uris: Collection<String>, tag: String) {
        val next = LinkedHashMap(_tags.value)
        uris.forEach { uri -> next[uri]?.let { next[uri] = it - tag } }
        _tags.value = next
        save()
    }

    // ----- housekeeping -----

    /** Files were deleted: forget them everywhere. */
    fun forget(uris: Collection<String>) {
        val gone = uris.toSet()
        _albums.value = LinkedHashMap<String, Set<String>>().also { map ->
            _albums.value.forEach { (k, v) -> map[k] = v - gone }
        }
        _tags.value = LinkedHashMap(_tags.value).also { map -> gone.forEach { map.remove(it) } }
        save()
    }

    /** A file got a new uri after a rename. */
    fun replaceUri(old: String, new: String) {
        if (old == new) return
        _albums.value = LinkedHashMap<String, Set<String>>().also { map ->
            _albums.value.forEach { (k, v) ->
                map[k] = if (old in v) LinkedHashSet(v).also { it.remove(old); it.add(new) } else v
            }
        }
        val oldTags = _tags.value[old]
        if (oldTags != null) {
            _tags.value = LinkedHashMap(_tags.value).also { it.remove(old); it[new] = oldTags }
        }
        save()
    }
}
