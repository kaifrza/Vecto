package com.vecto.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class TrashEntry(
    val id: String,
    val name: String,
    val originalPath: String,
    val sizeBytes: Long,
    val deletedAt: Long
)

/**
 * Recycle bin. Before a file is deleted a copy is kept in the app's private storage for [KEEP_DAYS] days,
 * so it can be restored. Restored files are saved to Pictures/Vecto.
 */
class TrashStore(private val context: Context) {
    private val dir = File(context.filesDir, "trash").also { it.mkdirs() }
    private val indexFile = File(dir, "index.json")

    private val _entries = MutableStateFlow(load())
    val entries: StateFlow<List<TrashEntry>> = _entries.asStateFlow()

    fun file(entry: TrashEntry) = File(dir, entry.id + ".svg")

    private fun load(): List<TrashEntry> {
        return try {
            if (!indexFile.exists()) return emptyList()
            val array = JSONArray(indexFile.readText())
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                TrashEntry(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    originalPath = o.optString("path"),
                    sizeBytes = o.optLong("size"),
                    deletedAt = o.optLong("at")
                )
            }.filter { File(dir, it.id + ".svg").exists() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun write(list: List<TrashEntry>) {
        _entries.value = list
        try {
            val array = JSONArray()
            list.forEach {
                array.put(
                    JSONObject()
                        .put("id", it.id).put("name", it.name).put("path", it.originalPath)
                        .put("size", it.sizeBytes).put("at", it.deletedAt)
                )
            }
            indexFile.writeText(array.toString())
        } catch (e: Exception) {
            // the in-memory list is still correct for this session
        }
    }

    /** Copies the file into the bin. Returns null when the file cannot be read. */
    fun add(item: SvgItem): TrashEntry? {
        val id = UUID.randomUUID().toString()
        val target = File(dir, "$id.svg")
        return try {
            context.contentResolver.openInputStream(item.parsedUri)?.use { input ->
                target.outputStream().use { input.copyTo(it) }
            } ?: return null
            val entry = TrashEntry(id, item.name, item.path.ifBlank { item.folderName }, target.length(), System.currentTimeMillis())
            write(_entries.value + entry)
            entry
        } catch (e: Exception) {
            target.delete()
            null
        }
    }

    fun remove(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val gone = ids.toSet()
        _entries.value.filter { it.id in gone }.forEach { file(it).delete() }
        write(_entries.value.filter { it.id !in gone })
    }

    fun purgeOld() {
        val limit = System.currentTimeMillis() - KEEP_DAYS * 24L * 60 * 60 * 1000
        remove(_entries.value.filter { it.deletedAt < limit }.map { it.id })
    }

    companion object {
        const val KEEP_DAYS = 30
    }
}
