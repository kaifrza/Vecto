package com.vecto.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vecto.app.R
import com.vecto.app.data.SvgItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

private const val MAX_BYTES = 2_000_000
private const val MAX_LINES = 5000
private const val MAX_LINE_CHARS = 1200

private class CodeDoc(val text: String, val lines: List<String>, val truncated: Boolean)

private fun loadCode(context: android.content.Context, uri: android.net.Uri): CodeDoc? {
    return try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(32 * 1024)
            var truncated = false
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                if (out.size() + n > MAX_BYTES) {
                    out.write(buffer, 0, MAX_BYTES - out.size())
                    truncated = true
                    break
                }
                out.write(buffer, 0, n)
            }
            val text = out.toString("UTF-8")
            val lines = ArrayList<String>()
            for (line in text.lineSequence()) {
                if (lines.size >= MAX_LINES) {
                    truncated = true
                    break
                }
                if (line.length <= MAX_LINE_CHARS) {
                    lines += line
                } else {
                    // minified SVG = one gigantic line; split so the list stays fast
                    line.chunked(MAX_LINE_CHARS).forEach { lines += it }
                }
            }
            CodeDoc(text, lines, truncated)
        }
    } catch (e: Exception) {
        null
    }
}

private val TagRegex = Regex("</?[A-Za-z][\\w:.-]*")
private val ValueRegex = Regex("\"[^\"]*\"|'[^']*'")

private fun highlight(line: String, tag: Color, value: Color): AnnotatedString = buildAnnotatedString {
    append(line)
    TagRegex.findAll(line).forEach { addStyle(SpanStyle(color = tag), it.range.first, it.range.last + 1) }
    ValueRegex.findAll(line).forEach { addStyle(SpanStyle(color = value), it.range.first, it.range.last + 1) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CodeSheet(item: SvgItem, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val doc by produceState<CodeDoc?>(null, item.uri) {
        value = withContext(Dispatchers.IO) { loadCode(context, item.parsedUri) }
    }
    val tagColor = MaterialTheme.colorScheme.primary
    val valueColor = MaterialTheme.colorScheme.tertiary

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(stringResource(R.string.code_title), style = MaterialTheme.typography.titleLarge)
                FilledTonalButton(
                    enabled = doc != null,
                    onClick = {
                        doc?.let {
                            clipboard.setText(AnnotatedString(it.text))
                            Toast.makeText(context, context.getString(R.string.copied), Toast.LENGTH_SHORT).show()
                        }
                    }
                ) { Text(stringResource(R.string.copy)) }
            }
            val d = doc
            if (d == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.code_loading), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                if (d.truncated) {
                    Text(
                        stringResource(R.string.code_truncated),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(d.lines) { _, line ->
                        val styled = remember(line, tagColor, valueColor) { highlight(line, tagColor, valueColor) }
                        Text(
                            styled,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
