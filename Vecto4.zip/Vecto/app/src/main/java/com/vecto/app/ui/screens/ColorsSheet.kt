package com.vecto.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.vecto.app.R
import com.vecto.app.data.SvgColors
import com.vecto.app.data.SvgItem
import com.vecto.app.data.readSvgText
import com.vecto.app.ui.SvgFiles
import com.vecto.app.ui.components.CheckerBoard
import com.vecto.app.ui.components.renderPreview
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private fun parse(hex: String): Int = android.graphics.Color.parseColor(hex)

/**
 * Shows every color used in the SVG. Tap one to change it everywhere in the file, see the result live,
 * then save a recolored copy (the original is never touched) or copy the code / HEX values.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColorsSheet(item: SvgItem, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val source by produceState<String?>(null, item.uri) { value = readSvgText(context, item.parsedUri) }
    val original = source
    val colors = remember(original) { if (original == null) emptyList() else SvgColors.extract(original) }
    var mapping by remember(original) { mutableStateOf<Map<String, String>>(emptyMap()) }
    var selected by remember(original) { mutableStateOf<String?>(null) }
    val recolored = remember(original, mapping) { original?.let { SvgColors.recolor(it, mapping) } }

    val preview by produceState<ImageBitmap?>(null, recolored) {
        val text = recolored ?: return@produceState
        delay(120) // debounce slider drags
        value = withContext(Dispatchers.Default) { renderPreview(text, 640)?.asImageBitmap() }
    }

    fun toast(text: String) = Toast.makeText(context, text, Toast.LENGTH_SHORT).show()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(bottom = 24.dp)
        ) {
            Text(stringResource(R.string.colors_title), style = MaterialTheme.typography.titleLarge)

            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .height(190.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                CheckerBoard(Modifier.fillMaxWidth().height(190.dp))
                preview?.let {
                    Image(
                        bitmap = it,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .padding(12.dp)
                    )
                }
            }

            if (original != null && colors.isEmpty()) {
                Text(
                    stringResource(R.string.colors_none),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 16.dp)
                )
            } else if (colors.isNotEmpty()) {
                Text(
                    stringResource(R.string.colors_tap_to_edit),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                )
            }

            colors.forEach { c ->
                val current = mapping[c.hex] ?: c.hex
                val changed = current != c.hex
                val isSelected = selected == c.hex
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { selected = if (isSelected) null else c.hex }
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(parse(current)))
                            .border(
                                if (isSelected) 3.dp else 1.dp,
                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                CircleShape
                            )
                    )
                    Column(Modifier.weight(1f)) {
                        Text(current, style = MaterialTheme.typography.titleSmall, fontFamily = FontFamily.Monospace)
                        Text(
                            if (changed) "${c.hex}  →  $current" else "${c.count}×",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = {
                        clipboard.setText(AnnotatedString(current))
                        toast(context.getString(R.string.copied))
                    }) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = stringResource(R.string.copy))
                    }
                }
                if (isSelected) {
                    ColorEditor(
                        key = c.hex,
                        current = current,
                        onChange = { hex ->
                            mapping = if (hex == c.hex) mapping - c.hex else mapping + (c.hex to hex)
                        }
                    )
                }
            }

            if (colors.isNotEmpty()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(top = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = {
                        clipboard.setText(AnnotatedString(colors.joinToString(", ") { mapping[it.hex] ?: it.hex }))
                        toast(context.getString(R.string.copied))
                    }) { Text(stringResource(R.string.colors_copy_all)) }
                    OutlinedButton(onClick = {
                        recolored?.let {
                            clipboard.setText(AnnotatedString(it))
                            toast(context.getString(R.string.copied))
                        }
                    }) { Text(stringResource(R.string.colors_copy_code)) }
                    if (mapping.isNotEmpty()) {
                        OutlinedButton(onClick = { mapping = emptyMap(); selected = null }) {
                            Text(stringResource(R.string.colors_reset))
                        }
                    }
                }
                FilledTonalButton(
                    enabled = mapping.isNotEmpty() && recolored != null,
                    onClick = {
                        val text = recolored ?: return@FilledTonalButton
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) {
                                    SvgFiles.saveText(context, item.title + "_recolor.svg", text)
                                }
                                toast(context.getString(R.string.colors_saved))
                            } catch (e: Exception) {
                                toast(e.message ?: context.getString(R.string.export_failed))
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text(stringResource(R.string.colors_save_copy), modifier = Modifier.padding(start = 8.dp))
                }
            }
        }
    }
}

/** HSV sliders + HEX field for one color. [key] resets the editor when another color is selected. */
@Composable
private fun ColorEditor(key: String, current: String, onChange: (String) -> Unit) {
    val start = remember(key) { FloatArray(3).also { android.graphics.Color.colorToHSV(parse(current), it) } }
    var h by remember(key) { mutableFloatStateOf(start[0]) }
    var s by remember(key) { mutableFloatStateOf(start[1]) }
    var v by remember(key) { mutableFloatStateOf(start[2]) }
    var hexText by remember(key) { mutableStateOf(current) }

    fun push() {
        val argb = android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))
        val hex = String.format(Locale.ROOT, "#%06X", 0xFFFFFF and argb)
        hexText = hex
        onChange(hex)
    }

    Column(Modifier.padding(start = 4.dp, end = 4.dp, bottom = 8.dp)) {
        OutlinedTextField(
            value = hexText,
            onValueChange = { text ->
                hexText = text
                val clean = text.trim()
                if (Regex("^#[0-9a-fA-F]{6}$").matches(clean)) {
                    val tmp = FloatArray(3)
                    android.graphics.Color.colorToHSV(parse(clean), tmp)
                    h = tmp[0]; s = tmp[1]; v = tmp[2]
                    onChange(clean.uppercase(Locale.ROOT))
                }
            },
            singleLine = true,
            label = { Text(stringResource(R.string.colors_hex)) },
            modifier = Modifier.fillMaxWidth()
        )
        EditSlider(stringResource(R.string.bg_hue), h, 0f, 360f) { h = it; push() }
        EditSlider(stringResource(R.string.bg_saturation), s, 0f, 1f) { s = it; push() }
        EditSlider(stringResource(R.string.bg_brightness), v, 0f, 1f) { v = it; push() }
    }
}

@Composable
private fun EditSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(84.dp))
        Slider(value = value, onValueChange = onChange, valueRange = min..max, modifier = Modifier.weight(1f))
    }
}
