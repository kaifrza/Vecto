package com.vecto.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.util.lerp
import kotlinx.coroutines.launch
import kotlin.math.max

/** Scale + pan of one viewer page. Read inside graphicsLayer {} so zooming never recomposes. */
@Stable
class ZoomState {
    var scale by mutableFloatStateOf(1f)
    var offsetX by mutableFloatStateOf(0f)
    var offsetY by mutableFloatStateOf(0f)

    val isZoomed: Boolean get() = scale > 1.02f

    fun reset() {
        scale = 1f
        offsetX = 0f
        offsetY = 0f
    }

    fun clampOffsets(width: Float, height: Float) {
        val maxX = max(0f, width * (scale - 1f) / 2f)
        val maxY = max(0f, height * (scale - 1f) / 2f)
        offsetX = offsetX.coerceIn(-maxX, maxX)
        offsetY = offsetY.coerceIn(-maxY, maxY)
    }

    /** Double tap: zoom into the tapped point, or back out if already zoomed. */
    suspend fun toggleZoom(tap: Offset, size: IntSize) {
        val w = size.width.toFloat()
        val h = size.height.toFloat()
        val startScale = scale
        val startX = offsetX
        val startY = offsetY
        val target = when {
            startScale < 1.5f -> 3f
            startScale < 5f -> 8f
            else -> 1f
        }
        val endX: Float
        val endY: Float
        if (target == 1f) {
            endX = 0f
            endY = 0f
        } else {
            val z = target / startScale
            val cx = tap.x - w / 2f
            val cy = tap.y - h / 2f
            val maxX = w * (target - 1f) / 2f
            val maxY = h * (target - 1f) / 2f
            endX = (cx * (1f - z) + z * startX).coerceIn(-maxX, maxX)
            endY = (cy * (1f - z) + z * startY).coerceIn(-maxY, maxY)
        }
        animate(0f, 1f, animationSpec = tween(260, easing = FastOutSlowInEasing)) { t, _ ->
            scale = lerp(startScale, target, t)
            offsetX = lerp(startX, endX, t)
            offsetY = lerp(startY, endY, t)
        }
    }
}

/**
 * Pinch to zoom, drag to pan (only while zoomed), double tap to toggle zoom, tap callback.
 * Single-finger drags are left alone when not zoomed so the pager can swipe between files.
 */
@Composable
fun Modifier.zoomable(state: ZoomState, onTap: () -> Unit, maxScale: Float = 40f): Modifier {
    val scope = rememberCoroutineScope()
    val latestTap by rememberUpdatedState(onTap)
    return this
        .pointerInput(state) {
            detectTapGestures(
                onTap = { latestTap() },
                onDoubleTap = { position -> scope.launch { state.toggleZoom(position, size) } }
            )
        }
        .pointerInput(state) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                do {
                    val event = awaitPointerEvent()
                    val pressedCount = event.changes.count { it.pressed }
                    val consumedByOther = event.changes.any { it.isConsumed }
                    // pressedCount == 0 is the final "finger up" event: centroid is undefined there (NaN) - skip it.
                    if (!consumedByOther && pressedCount > 0 && (pressedCount > 1 || state.isZoomed)) {
                        val zoomChange = event.calculateZoom()
                        val pan = event.calculatePan()
                        val centroid = event.calculateCentroid()
                        if (centroid.isSpecified && zoomChange.isFinite() && pan.x.isFinite() && pan.y.isFinite()) {
                            val newScale = (state.scale * zoomChange).coerceIn(1f, maxScale)
                            val effective = newScale / state.scale
                            val cx = centroid.x - size.width / 2f
                            val cy = centroid.y - size.height / 2f
                            state.offsetX = cx * (1f - effective) + effective * state.offsetX + pan.x
                            state.offsetY = cy * (1f - effective) + effective * state.offsetY + pan.y
                            state.scale = newScale
                            state.clampOffsets(size.width.toFloat(), size.height.toFloat())
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    }
                } while (!consumedByOther && event.changes.any { it.pressed })
            }
        }
}
