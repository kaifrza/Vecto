package com.vecto.app.ui.screens

import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.vecto.app.R
import androidx.compose.foundation.Image
import androidx.compose.runtime.produceState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import com.vecto.app.ui.components.SvgDoc
import com.vecto.app.ui.components.loadSvgDoc
import com.vecto.app.ui.components.renderDetail
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext
import kotlin.math.min
import com.vecto.app.data.SvgItem
import com.vecto.app.data.ViewerState
import com.vecto.app.ui.components.BrowserSvg
import com.vecto.app.ui.components.CheckerBoard
import com.vecto.app.ui.components.ZoomState
import com.vecto.app.ui.components.zoomable
import com.vecto.app.ui.theme.HeartColor

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ViewerScreen(
    state: ViewerState,
    favorites: Set<String>,
    bgMode: Int,
    bgColor: Int,
    onBgMode: (Int) -> Unit,
    onBgColor: (Int) -> Unit,
    onToggleFavorite: (SvgItem) -> Unit,
    onShare: (SvgItem) -> Unit,
    onClose: () -> Unit
) {
    val items = state.items
    val pagerState = rememberPagerState(initialPage = state.index) { items.size }
    var chrome by rememberSaveable { mutableStateOf(true) }
    var browser by rememberSaveable { mutableStateOf(false) }
    var showInfo by rememberSaveable { mutableStateOf(false) }
    var showBg by rememberSaveable { mutableStateOf(false) }
    var zoomed by remember { mutableStateOf(false) }

    val page = pagerState.currentPage.coerceIn(0, items.lastIndex)
    val current = items[page]
    val isFavorite = current.uri in favorites
    val context = LocalContext.current
    val colors = MaterialTheme.colorScheme

    BackHandler(onBack = onClose)

    val canvasColor = when (bgMode) {
        1 -> Color.White
        2 -> Color.Black
        3 -> Color.White
        4 -> Color(bgColor)
        else -> colors.background
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(canvasColor)
    ) {
        if (bgMode == 3) CheckerBoard(Modifier.fillMaxSize())

        HorizontalPager(
            state = pagerState,
            userScrollEnabled = !zoomed && !browser,
            key = { items[it].uri },
            modifier = Modifier.fillMaxSize()
        ) { index ->
            ViewerPage(
                item = items[index],
                index = index,
                pagerState = pagerState,
                browser = browser,
                onTap = { chrome = !chrome },
                onZoomedChange = { zoomed = it },
                onTryBrowser = { browser = true }
            )
        }

        AnimatedVisibility(
            visible = chrome,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(160)) + slideInVertically(tween(200)) { -it / 3 },
            exit = fadeOut(tween(120)) + slideOutVertically(tween(160)) { -it / 3 }
        ) {
            Surface(
                color = colors.surface.copy(alpha = 0.93f),
                shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
                shadowElevation = 3.dp
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            current.title,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val sizeText = if (current.sizeBytes > 0) {
                            " · " + Formatter.formatShortFileSize(context, current.sizeBytes)
                        } else {
                            ""
                        }
                        Text(
                            "${page + 1} / ${items.size}$sizeText",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.onSurfaceVariant
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = chrome,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(160)) + slideInVertically(tween(200)) { it / 3 },
            exit = fadeOut(tween(120)) + slideOutVertically(tween(160)) { it / 3 }
        ) {
            Surface(
                color = colors.surface.copy(alpha = 0.93f),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                shadowElevation = 3.dp
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ActionButton(Icons.Rounded.Share, stringResource(R.string.share), onClick = { onShare(current) })
                    ActionButton(
                        icon = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        label = stringResource(R.string.favorite),
                        tint = if (isFavorite) HeartColor else null,
                        onClick = { onToggleFavorite(current) }
                    )
                    ActionButton(Icons.Rounded.Palette, stringResource(R.string.background), onClick = { showBg = true })
                    ActionButton(
                        icon = Icons.Rounded.Language,
                        label = stringResource(if (browser) R.string.engine_browser else R.string.engine_default),
                        active = browser,
                        onClick = { browser = !browser }
                    )
                    ActionButton(Icons.Rounded.Info, stringResource(R.string.info), onClick = { showInfo = true })
                }
            }
        }
    }

    if (showInfo) {
        InfoSheet(item = current, onDismiss = { showInfo = false })
    }
    if (showBg) {
        BackgroundSheet(
            mode = bgMode,
            color = bgColor,
            onMode = onBgMode,
            onColor = onBgColor,
            onDismiss = { showBg = false }
        )
    }
}

@Composable
private fun ViewerPage(
    item: SvgItem,
    index: Int,
    pagerState: PagerState,
    browser: Boolean,
    onTap: () -> Unit,
    onZoomedChange: (Boolean) -> Unit,
    onTryBrowser: () -> Unit
) {
    val zoom = remember { ZoomState() }
    val isCurrent = pagerState.currentPage == index

    LaunchedEffect(browser) { zoom.reset() }
    LaunchedEffect(isCurrent, zoom.isZoomed, browser) {
        if (isCurrent) onZoomedChange(zoom.isZoomed && !browser) else zoom.reset()
    }

    if (browser) {
        BrowserSvg(uri = item.uri, modifier = Modifier.fillMaxSize())
    } else {
        ZoomableSvg(item = item, zoom = zoom, onTap = onTap, onTryBrowser = onTryBrowser)
    }
}

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@Composable
private fun ZoomableSvg(
    item: SvgItem,
    zoom: ZoomState,
    onTap: () -> Unit,
    onTryBrowser: () -> Unit
) {
    val context = LocalContext.current
    val padPx = with(LocalDensity.current) { 16.dp.toPx() }
    var failed by remember(item.uri) { mutableStateOf(false) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var detail by remember(item.uri) { mutableStateOf<ImageBitmap?>(null) }
    val doc by produceState<SvgDoc?>(null, item.uri) { value = loadSvgDoc(context, item.parsedUri) }

    val request = remember(item.uri, item.modifiedSec) {
        ImageRequest.Builder(context)
            .data(item.parsedUri)
            .size(2048)
            .setParameter("m", item.modifiedSec)
            .crossfade(true)
            .build()
    }

    // Zoom is a fast scaled bitmap while fingers move. ~140 ms after the gesture settles, the visible
    // part is re-drawn as true vectors, so even 40x zoom stays sharp.
    LaunchedEffect(doc, boxSize) {
        val d = doc ?: return@LaunchedEffect
        if (boxSize.width <= 0 || boxSize.height <= 0) return@LaunchedEffect
        val w = boxSize.width.toFloat()
        val h = boxSize.height.toFloat()
        val fit = min((w - 2 * padPx) / d.width, (h - 2 * padPx) / d.height)
        snapshotFlow { Triple(zoom.scale, zoom.offsetX, zoom.offsetY) }
            .onEach { detail = null }
            .debounce(140)
            .collectLatest { (scale, ox, oy) ->
                if (scale < 1.25f) return@collectLatest
                val k = scale * fit
                val cw = d.width * k
                val ch = d.height * k
                val bitmap = withContext(Dispatchers.Default) {
                    renderDetail(d, boxSize.width, boxSize.height, w / 2f + ox - cw / 2f, h / 2f + oy - ch / 2f, cw, ch)
                }
                detail = bitmap?.asImageBitmap()
            }
    }

    Box(
        Modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { boxSize = it }
            .zoomable(zoom, onTap),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = request,
            contentDescription = item.title,
            contentScale = ContentScale.Fit,
            onError = { failed = true },
            onSuccess = { failed = false },
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .graphicsLayer {
                    scaleX = zoom.scale
                    scaleY = zoom.scale
                    translationX = zoom.offsetX
                    translationY = zoom.offsetY
                    alpha = if (detail != null) 0f else 1f
                }
        )
        detail?.let {
            Image(
                bitmap = it,
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
        }
        if (failed && doc == null) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHighest,
                modifier = Modifier.padding(32.dp)
            ) {
                Column(
                    Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        stringResource(R.string.render_failed),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FilledTonalButton(onClick = onTryBrowser) {
                        Text(stringResource(R.string.render_try_browser))
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    active: Boolean = false,
    tint: Color? = null
) {
    val colors = MaterialTheme.colorScheme
    val iconColor = tint ?: if (active) colors.primary else colors.onSurface
    Column(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .defaultMinSize(minWidth = 56.dp)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = iconColor)
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) colors.primary else colors.onSurfaceVariant,
            maxLines = 1
        )
    }
}
