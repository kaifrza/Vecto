package com.vecto.app.ui.screens

import android.text.format.Formatter
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.vecto.app.R
import com.vecto.app.data.SvgItem
import com.vecto.app.data.SvgMeta
import com.vecto.app.data.readSvgMeta
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InfoSheet(item: SvgItem, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var meta by remember(item.uri) { mutableStateOf<SvgMeta?>(null) }
    LaunchedEffect(item.uri) { meta = readSvgMeta(context, item.parsedUri) }

    val unknown = stringResource(R.string.info_unknown)
    val modified = remember(item.modifiedSec) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
            .format(Date(item.modifiedSec * 1000))
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp)
                .navigationBarsPadding()
        ) {
            Text(item.title, style = MaterialTheme.typography.titleLarge, maxLines = 2)
            Spacer(Modifier.height(16.dp))
            InfoRow(stringResource(R.string.info_name), item.name)
            InfoRow(stringResource(R.string.info_folder), item.folderName)
            InfoRow(stringResource(R.string.info_path), item.path.ifBlank { item.uri })
            InfoRow(
                stringResource(R.string.info_size),
                if (item.sizeBytes > 0) Formatter.formatShortFileSize(context, item.sizeBytes) else unknown
            )
            InfoRow(stringResource(R.string.info_dimensions), meta?.dimensions ?: unknown)
            meta?.viewBox?.let { InfoRow(stringResource(R.string.info_viewbox), it) }
            InfoRow(stringResource(R.string.info_modified), modified)
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        SelectionContainer { Text(value, style = MaterialTheme.typography.bodyLarge) }
    }
}
