package com.vecto.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.SvgDecoder
import coil.memory.MemoryCache
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher

/**
 * One shared Coil image loader that knows how to decode SVG.
 * Decoding is limited to 4 low-priority threads so fast scrolling never starves the UI thread,
 * and the memory cache is larger so thumbnails are not re-decoded when scrolling back.
 */
class VectoApp : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader {
        val pool = Executors.newFixedThreadPool(4) { task ->
            Thread(task, "svg-decode").apply { priority = Thread.NORM_PRIORITY - 1 }
        }
        return ImageLoader.Builder(this)
            .components { add(SvgDecoder.Factory()) }
            .decoderDispatcher(pool.asCoroutineDispatcher())
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.30).build() }
            .respectCacheHeaders(false)
            .build()
    }
}
