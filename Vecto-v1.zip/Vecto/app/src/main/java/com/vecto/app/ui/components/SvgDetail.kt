package com.vecto.app.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import com.caverock.androidsvg.RenderOptions
import com.caverock.androidsvg.SVG
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** A parsed SVG plus its intrinsic size, used to re-render crisp detail at any zoom level. */
class SvgDoc(val svg: SVG, val width: Float, val height: Float)

suspend fun loadSvgDoc(context: Context, uri: Uri): SvgDoc? = withContext(Dispatchers.IO) {
    try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val svg = SVG.getFromInputStream(input)
            val box = svg.documentViewBox
            var w = svg.documentWidth
            var h = svg.documentHeight
            if (box != null && box.width() > 0f && box.height() > 0f) {
                w = box.width()
                h = box.height()
            }
            if (w <= 0f || h <= 0f) null else SvgDoc(svg, w, h)
        }
    } catch (e: Exception) {
        null
    }
}

/**
 * Draws the SVG as vectors into a screen-sized bitmap. [left]/[top]/[contentW]/[contentH] describe where
 * the whole drawing sits on screen (may be far larger than the bitmap when zoomed in a lot);
 * only the visible part is actually painted, so memory stays small and edges stay razor sharp.
 */
fun renderDetail(doc: SvgDoc, width: Int, height: Int, left: Float, top: Float, contentW: Float, contentH: Float): Bitmap? {
    return try {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        synchronized(doc.svg) {
            doc.svg.renderToCanvas(Canvas(bitmap), RenderOptions.create().viewPort(left, top, contentW, contentH))
        }
        bitmap
    } catch (e: Exception) {
        null
    } catch (e: OutOfMemoryError) {
        null
    }
}
