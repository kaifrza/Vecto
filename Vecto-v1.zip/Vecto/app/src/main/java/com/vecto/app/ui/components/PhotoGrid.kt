package com.vecto.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.vecto.app.data.SvgItem
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

sealed interface GridEntry {
    val key: String

    data class Header(val title: String) : GridEntry {
        override val key: String = "h:$title"
    }

    data class Photo(val item: SvgItem, val index: Int) : GridEntry {
        override val key: String = item.uri
    }
}

/** Turns a flat list into date sections ("Today", "Yesterday", "Mon, 24 Nov"...) when [grouped]. */
fun buildEntries(items: List<SvgItem>, grouped: Boolean, today: String, yesterday: String): List<GridEntry> {
    if (!grouped) return items.mapIndexed { index, item -> GridEntry.Photo(item, index) }

    val zone = ZoneId.systemDefault()
    val now = LocalDate.now(zone)
    val sameYear = DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault())
    val otherYear = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())
    val out = ArrayList<GridEntry>(items.size + 32)
    var lastDate: LocalDate? = null
    items.forEachIndexed { index, item ->
        val date = Instant.ofEpochSecond(item.modifiedSec).atZone(zone).toLocalDate()
        if (date != lastDate) {
            lastDate = date
            val title = when {
                date == now -> today
                date == now.minusDays(1) -> yesterday
                date.year == now.year -> date.format(sameYear)
                else -> date.format(otherYear)
            }
            out += GridEntry.Header(title)
        }
        out += GridEntry.Photo(item, index)
    }
    return out
}

@Composable
fun PhotoGrid(
    entries: List<GridEntry>,
    columns: Int,
    fit: Boolean,
    selection: Set<String>,
    favorites: Set<String>,
    onOpen: (index: Int) -> Unit,
    onToggleSelect: (SvgItem) -> Unit,
    modifier: Modifier = Modifier,
    state: LazyGridState = rememberLazyGridState(),
    contentPadding: PaddingValues = PaddingValues(horizontal = 2.dp),
    topContent: (@Composable () -> Unit)? = null
) {
    val selecting = selection.isNotEmpty()
    // Decode thumbnails at roughly the on-screen size: smaller bitmaps = faster scrolling.
    val screenWidth = LocalContext.current.resources.displayMetrics.widthPixels
    val thumbPx = (screenWidth / columns).coerceIn(160, 384)
    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        state = state,
        modifier = modifier,
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        if (topContent != null) {
            item(key = "top", span = { GridItemSpan(maxLineSpan) }) { topContent() }
        }
        items(
            items = entries,
            key = { it.key },
            span = { entry ->
                if (entry is GridEntry.Header) GridItemSpan(maxLineSpan) else GridItemSpan(1)
            },
            contentType = { it::class }
        ) { entry ->
            when (entry) {
                is GridEntry.Header -> DateHeader(entry.title)
                is GridEntry.Photo -> SvgTile(
                    item = entry.item,
                    fit = fit,
                    selected = entry.item.uri in selection,
                    selectionMode = selecting,
                    favorite = entry.item.uri in favorites,
                    onClick = {
                        if (selecting) onToggleSelect(entry.item) else onOpen(entry.index)
                    },
                    onLongClick = { onToggleSelect(entry.item) },
                    px = thumbPx
                )
            }
        }
    }
}

@Composable
private fun DateHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 20.dp, bottom = 8.dp)
    )
}
