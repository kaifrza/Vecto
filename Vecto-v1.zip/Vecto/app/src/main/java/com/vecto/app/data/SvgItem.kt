package com.vecto.app.data

import android.net.Uri
import androidx.compose.runtime.Immutable

@Immutable
data class SvgItem(
    val uri: String,
    val name: String,
    val sizeBytes: Long,
    /** Last modified, seconds since epoch. */
    val modifiedSec: Long,
    /** Stable id of the containing folder (used for grouping into albums). */
    val folderKey: String,
    /** Human readable folder name. */
    val folderName: String,
    /** Full path on storage when known, otherwise empty. */
    val path: String = ""
) {
    val title: String
        get() = if (name.endsWith(".svg", ignoreCase = true)) name.dropLast(4) else name

    val parsedUri: Uri
        get() = Uri.parse(uri)
}

enum class SortMode { NEWEST, OLDEST, NAME, SIZE }

data class Album(val key: String, val name: String, val items: List<SvgItem>)

data class ViewerState(
    val items: List<SvgItem>,
    val index: Int,
    val nonce: Long,
    /** Opened from another app (file manager, share sheet). */
    val external: Boolean = false
)

fun groupAlbums(items: List<SvgItem>): List<Album> =
    items.groupBy { it.folderKey }
        .map { (key, list) -> Album(key, list.first().folderName, list) }
        .sortedByDescending { album -> album.items.maxOf { it.modifiedSec } }
