package com.vecto.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.vecto.app.R

private val Swatches = listOf(
    Color(0xFFFFFFFF), Color(0xFFF1F5F9), Color(0xFF9CA3AF), Color(0xFF374151), Color(0xFF000000),
    Color(0xFFEF4444), Color(0xFFF97316), Color(0xFFEAB308), Color(0xFF22C55E), Color(0xFF14B8A6),
    Color(0xFF3B82F6), Color(0xFF6366F1), Color(0xFFA855F7), Color(0xFFEC4899), Color(0xFF7C2D12),
    Color(0xFF0F172A)
)

private fun toHsv(argb: Int): FloatArray {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(argb, hsv)
    return hsv
}

/** Pick a preset (theme / white / black / checkerboard), a swatch, or mix any color with HSV sliders. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackgroundSheet(
    mode: Int,
    color: Int,
    onMode: (Int) -> Unit,
    onColor: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var hsv by remember { mutableStateOf(toHsv(color)) }
    val current = android.graphics.Color.HSVToColor(hsv)

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
                .navigationBarsPadding()
        ) {
            Text(stringResource(R.string.bg_title), style = MaterialTheme.typography.titleLarge)

            Label(stringResource(R.string.bg_presets))
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(mode == 0, { onMode(0) }, { Text(stringResource(R.string.bg_theme)) })
                FilterChip(mode == 1, { onMode(1) }, { Text(stringResource(R.string.bg_white)) })
                FilterChip(mode == 2, { onMode(2) }, { Text(stringResource(R.string.bg_black)) })
                FilterChip(mode == 3, { onMode(3) }, { Text(stringResource(R.string.bg_checker)) })
            }

            Label(stringResource(R.string.bg_colors))
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Swatches.forEach { swatch ->
                    val selected = mode == 4 && color == swatch.toArgb()
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(swatch)
                            .border(
                                if (selected) 3.dp else 1.dp,
                                if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                CircleShape
                            )
                            .clickable {
                                hsv = toHsv(swatch.toArgb())
                                onColor(swatch.toArgb())
                            }
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 18.dp)) {
                Label(stringResource(R.string.bg_custom), Modifier.weight(1f), topPadding = 0)
                Box(
                    Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(current))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                )
            }
            HsvSlider(stringResource(R.string.bg_hue), hsv[0], 0f, 360f) {
                hsv = floatArrayOf(it, hsv[1], hsv[2]); onColor(android.graphics.Color.HSVToColor(hsv))
            }
            HsvSlider(stringResource(R.string.bg_saturation), hsv[1], 0f, 1f) {
                hsv = floatArrayOf(hsv[0], it, hsv[2]); onColor(android.graphics.Color.HSVToColor(hsv))
            }
            HsvSlider(stringResource(R.string.bg_brightness), hsv[2], 0f, 1f) {
                hsv = floatArrayOf(hsv[0], hsv[1], it); onColor(android.graphics.Color.HSVToColor(hsv))
            }
        }
    }
}

@Composable
private fun Label(text: String, modifier: Modifier = Modifier, topPadding: Int = 16) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier.padding(top = topPadding.dp, bottom = 8.dp)
    )
}

@Composable
private fun HsvSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.size(width = 84.dp, height = 20.dp)
        )
        Slider(value = value, onValueChange = onChange, valueRange = min..max, modifier = Modifier.weight(1f))
    }
}
